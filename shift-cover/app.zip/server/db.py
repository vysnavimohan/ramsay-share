"""SQL-warehouse data layer via Statement Execution REST API (no heavy deps).
Local: AAD token via env DATABRICKS_TOKEN + DATABRICKS_HOST.
In Databricks Apps: injected SP OAuth (DATABRICKS_TOKEN or WorkspaceClient)."""
import os, json, time, urllib.request, urllib.error

HOST = os.environ.get("DATABRICKS_HOST", "").replace("https://", "")
WAREHOUSE_ID = os.environ["WAREHOUSE_ID"]


def _token() -> str:
    tok = os.environ.get("DATABRICKS_TOKEN")
    if tok:
        return tok
    from databricks.sdk import WorkspaceClient
    return WorkspaceClient().config.authenticate()["Authorization"].replace("Bearer ", "")


def _base():
    h = HOST if HOST.startswith("http") else "https://" + HOST
    return h.rstrip("/")


def query(sql_text: str, params: dict | None = None) -> list[dict]:
    """Run SQL on the warehouse. params -> named parameters (:name). %(name)s style
    from call sites is converted to :name for the Statement API."""
    api_params = None
    if params:
        for k in params:
            sql_text = sql_text.replace(f"%({k})s", f":{k}")
        api_params = [{"name": k, "value": (None if v is None else str(v))} for k, v in params.items()]
    body = {"warehouse_id": WAREHOUSE_ID, "statement": sql_text, "wait_timeout": "50s",
            "format": "JSON_ARRAY", "disposition": "INLINE"}
    if api_params:
        body["parameters"] = api_params
    req = urllib.request.Request(_base() + "/api/2.0/sql/statements",
                                 data=json.dumps(body).encode(),
                                 headers={"Authorization": "Bearer " + _token(), "Content-Type": "application/json"},
                                 method="POST")
    # urllib raises HTTPError WITHOUT the response body, which made every failure an opaque
    # "500 Internal Server Error" in the UI with nothing to debug. Always surface the body.
    try:
        d = json.loads(urllib.request.urlopen(req).read())
    except urllib.error.HTTPError as e:
        detail = e.read().decode(errors="replace")[:600]
        raise RuntimeError(f"Statement API HTTP {e.code}: {detail}") from None
    sid = d.get("statement_id")
    # poll if still running
    while d.get("status", {}).get("state") in ("PENDING", "RUNNING"):
        time.sleep(1)
        r2 = urllib.request.Request(_base() + f"/api/2.0/sql/statements/{sid}",
                                    headers={"Authorization": "Bearer " + _token()}, method="GET")
        try:
            d = json.loads(urllib.request.urlopen(r2).read())
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"Statement poll HTTP {e.code}: "
                               f"{e.read().decode(errors='replace')[:400]}") from None
    st = d.get("status", {})
    if st.get("state") != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + str(st.get("error", {}).get("message", ""))[:300])
    cols = [c["name"] for c in d.get("manifest", {}).get("schema", {}).get("columns", [])]
    rows = d.get("result", {}).get("data_array", []) or []
    return [dict(zip(cols, r)) for r in rows]
