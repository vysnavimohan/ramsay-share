"""API routes: gaps, replacement finder, ROI, Genie proxy, AND the action layer
(assign write-back, savings ledger, whole-estate optimiser, LLM AI co-worker)."""
import os, time, json, uuid, urllib.request, urllib.error
from datetime import datetime
from fastapi import APIRouter, HTTPException
from ..db import query, _token, HOST

router = APIRouter()
CS = os.environ.get("CATALOG_SCHEMA", "ramsay_workforce.allocate")
GENIE_SPACE = os.environ.get("GENIE_SPACE_ID", "")
COWORKER_MODEL = os.environ.get("COWORKER_MODEL", "databricks-gpt-oss-120b")  # in-geo real-time endpoint


def _f(v):
    """Coerce Statement-API string values to float (0.0 on None/blank)."""
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


@router.get("/gaps")
def gaps(days: int = 7, site: str | None = None, grade: str | None = None):
    where = [f"ShiftDate <= current_date() + {int(days)}", "ShiftDate >= current_date()"]
    p = {}
    if site:
        where.append("SiteName = %(site)s"); p["site"] = site
    if grade:
        where.append("Grade = %(grade)s"); p["grade"] = grade
    # exclude gaps already resolved via the app (write-back state)
    where.append(f"HoursAssignmentID NOT IN (SELECT HoursAssignmentID FROM {CS}.cover_decisions WHERE status='ASSIGNED')")
    return query(f"""SELECT HoursAssignmentID, SiteName, Grade, GradeName, ShiftDate, ShiftName,
        ShiftType, GapReason, PlannedAgencyHours, agency_cost_if_unfilled, saving_if_filled_internally
        FROM {CS}.vw_open_gaps WHERE {' AND '.join(where)} ORDER BY agency_cost_if_unfilled DESC""", p)


@router.get("/board")
def board(days: int = 7):
    """Main board: every open position in the window, each with its top-3 internal
    cover OPTIONS (ranked), current outreach status per option, and the agency cost
    if left unfilled.

    ONE round trip. This used to be three sequential queries (candidates, headers,
    outreach), and the candidate one recomputed ~25k gap x candidate pairs on every page
    load — measured 5.1s for a 7d window, and 30d is 1,801 gaps. Two things changed:
      * the ranked top-3 now comes precomputed from the mv_gap_candidates materialized
        view (hourly schedule, built in build/80_board_ux_objects.py);
      * headers, candidates and outreach are joined server-side into a single statement,
        because each Statement-API round trip costs ~2.4s of fixed overhead regardless of
        how little work it does. Three cheap queries lost to latency what the MV saved.

    Candidates are sourced from vw_open_gaps, so BOTH kinds of gap get options: an
    unfilled roster post AND a shift whose rostered nurse is off sick. The old query
    filtered candidates to unfilled-only while the header query returned both, so 183
    sickness gaps with real internal cover were being reported as "needs agency".
    """
    days = int(days)
    rows = query(f"""
        WITH h AS (
          SELECT HoursAssignmentID, SiteName, Grade, GradeName, ShiftDate, ShiftName, ShiftType,
                 GapReason, agency_cost_if_unfilled,
                 ResourcingUnitShortName, PersonGradeLongName, RequiredGradeShortName,
                 shift_hours, ShiftStartDate, ShiftEndDate,
                 is_unfilled, absent_staff_name, absent_staff_number, absence_reason_group
          FROM {CS}.vw_open_gaps
          WHERE ShiftDate BETWEEN current_date() AND current_date()+{days}
            AND HoursAssignmentID NOT IN (SELECT HoursAssignmentID FROM {CS}.cover_decisions WHERE status='ASSIGNED')
        ),
        -- Latest outreach attempt per (gap, staff). Keyed on StaffNumber: person NAMES are
        -- not unique here (108 shared names, five "Priya Hughes"), so keying on name made
        -- "reached out" show against every namesake. assigned_staff is the fallback for
        -- rows written before assigned_staff_number existed.
        o AS (
          SELECT HoursAssignmentID, assigned_staff, assigned_staff_number,
                 coalesce(outreach_status,'REACHED_OUT') AS outreach_status
          FROM {CS}.cover_decisions WHERE status IN ('OFFERED','ASSIGNED')
        )
        SELECT h.*, m.rnk, m.StaffNumber, m.Name, m.EmployeeType,
               m.distance_km, m.hours_last_7d, m.saving,
               coalesce(o1.outreach_status, o2.outreach_status) AS outreach_status
        FROM h
        LEFT JOIN {CS}.mv_gap_candidates m ON m.HoursAssignmentID = h.HoursAssignmentID
        LEFT JOIN o o1 ON o1.HoursAssignmentID = h.HoursAssignmentID
                      AND o1.assigned_staff_number = m.StaffNumber
        LEFT JOIN o o2 ON o2.HoursAssignmentID = h.HoursAssignmentID
                      AND o2.assigned_staff_number IS NULL
                      AND o2.assigned_staff = m.Name
        ORDER BY h.agency_cost_if_unfilled DESC, h.HoursAssignmentID, m.rnk""")

    # Fan the flat join back into one entry per gap, preserving the SQL ordering.
    board, by_id = [], {}
    for r in rows:
        gid = r["HoursAssignmentID"]
        g = by_id.get(gid)
        if g is None:
            g = {
                "HoursAssignmentID": gid, "SiteName": r["SiteName"], "Grade": r["Grade"],
                "GradeName": r.get("GradeName"), "ShiftDate": str(r["ShiftDate"]),
                "ShiftName": r["ShiftName"], "ShiftType": r.get("ShiftType"),
                "GapReason": r["GapReason"],
                "agency_cost_if_unfilled": _f(r["agency_cost_if_unfilled"]),
                # card-header fields [H1]
                "Ward": r.get("ResourcingUnitShortName"),
                "PersonGradeLongName": r.get("PersonGradeLongName"),
                "RequiredGradeShortName": r.get("RequiredGradeShortName"),
                "shift_hours": _f(r.get("shift_hours")),
                "ShiftStartDate": str(r.get("ShiftStartDate") or ""),
                "ShiftEndDate": str(r.get("ShiftEndDate") or ""),
                # True = vacant roster post (nobody to name). False = a real named absence,
                # and absent_staff_* come straight off the roster — never inferred. [H6][H7]
                "is_unfilled": str(r.get("is_unfilled")).lower() == "true",
                "absent_staff_name": r.get("absent_staff_name"),
                "absent_staff_number": r.get("absent_staff_number"),
                "absence_reason_group": r.get("absence_reason_group"),
                "options": [],
            }
            by_id[gid] = g
            board.append(g)
        # LEFT JOIN yields one all-NULL candidate row for a gap with no eligible cover.
        if r.get("StaffNumber"):
            g["options"].append({
                "rank": int(_f(r["rnk"])), "staff": r["StaffNumber"], "name": r["Name"],
                "type": r["EmployeeType"], "distance_km": _f(r["distance_km"]),
                "hours_last_7d": _f(r["hours_last_7d"]), "saving": _f(r["saving"]),
                "outreach": r.get("outreach_status") or "NONE"})

    for g in board:
        g["has_internal"] = len(g["options"]) > 0
    return {"days": days, "count": len(board), "gaps": board}


@router.post("/outreach")
def outreach(body: dict):
    """Record that a manager has reached out to a candidate for a gap, and the reply.
    status: OFFERED (reached out, awaiting) ; on ACCEPTED we flip to ASSIGNED (fills the gap
    + banks the saving); on DECLINED we keep it OFFERED-declined so the marker shows."""
    gid = int(body["HoursAssignmentID"])
    name = body.get("staff_name")
    reply = body.get("reply", "REACHED_OUT")  # REACHED_OUT | ACCEPTED | DECLINED
    did = str(uuid.uuid4())[:8]
    accepted = reply == "ACCEPTED"
    query(_insert_decision({
        "decision_id": did, "HoursAssignmentID": gid, "SiteName": body.get("SiteName"),
        "Grade": body.get("Grade"), "ShiftDate": body.get("ShiftDate"), "assigned_staff": name,
        "assigned_staff_number": body.get("staff_number"),
        "assigned_type": body.get("assigned_type"), "distance_km": body.get("distance_km"),
        "saving_gbp": body.get("saving_gbp"),
        "rationale": body.get("rationale", "Manager outreach — accepted" if accepted else "Manager outreach"),
        "decided_by": body.get("decided_by", "ops-manager"),
        "status": "ASSIGNED" if accepted else "OFFERED",
        "outreach_status": reply, "resolution_mode": "MANAGER"}))
    return ({"ok": True, "state": "ASSIGNED", "decision_id": did} if accepted
            else {"ok": True, "state": "OFFERED", "reply": reply, "decision_id": did})


@router.get("/savings")
def savings():
    """Consolidated money tab: everything monetary lives here.
    Splits realized savings by resolution_mode (AUTO vs MANAGER) and shows the
    agency charge avoided vs the internal-replacement saving."""
    tot = query(f"""SELECT
        COALESCE(SUM(saving_gbp),0) total_saved,
        COUNT(*) shifts_covered,
        COALESCE(SUM(CASE WHEN resolution_mode='AUTO' THEN saving_gbp ELSE 0 END),0) auto_saved,
        COALESCE(SUM(CASE WHEN resolution_mode='AUTO' THEN 1 ELSE 0 END),0) auto_shifts,
        COALESCE(SUM(CASE WHEN resolution_mode='MANAGER' THEN saving_gbp ELSE 0 END),0) manager_saved,
        COALESCE(SUM(CASE WHEN resolution_mode='MANAGER' THEN 1 ELSE 0 END),0) manager_shifts
        FROM {CS}.cover_decisions WHERE status='ASSIGNED'""")
    # opportunity still on the table (unresolved coverable gaps, 30d)
    opp = query(f"""SELECT COALESCE(SUM(saving_if_filled_internally),0) open_saving, COUNT(*) open_gaps
        FROM {CS}.vw_open_gaps WHERE ShiftDate <= current_date()+30
          AND HoursAssignmentID NOT IN (SELECT HoursAssignmentID FROM {CS}.cover_decisions WHERE status='ASSIGNED')""")
    by_site = query(f"""SELECT Site, MEASURE(agency_cost) agency_cost, MEASURE(agency_premium) agency_premium
        FROM {CS}.mv_shift_fulfilment GROUP BY Site ORDER BY agency_premium DESC""")
    totals = query(f"""SELECT MEASURE(agency_cost) agency_cost, MEASURE(agency_premium) agency_premium,
        MEASURE(fill_rate) fill_rate FROM {CS}.mv_shift_fulfilment""")
    recent = query(f"""SELECT decision_id, SiteName, Grade, ShiftDate, assigned_staff, assigned_type,
        saving_gbp, resolution_mode, decided_at FROM {CS}.cover_decisions WHERE status='ASSIGNED'
        ORDER BY decided_at DESC LIMIT 20""")
    return {"totals": tot[0] if tot else {}, "opportunity": opp[0] if opp else {},
            "estate": totals[0] if totals else {}, "by_site": by_site, "recent": recent}


@router.get("/replacements/{gap_id}")
def replacements(gap_id: int):
    return query(f"""SELECT Name, Grade, EmployeeType, HomeSite, distance_km, hours_last_7d,
        contract_rank, saving_vs_agency FROM {CS}.fn_find_replacements({int(gap_id)})""")


@router.get("/roi")
def roi():
    by_site = query(f"""SELECT Site, MEASURE(agency_premium) AS agency_premium,
        MEASURE(agency_cost) AS agency_cost, MEASURE(fill_rate) AS fill_rate,
        MEASURE(unfilled_shifts) AS unfilled_shifts
        FROM {CS}.mv_shift_fulfilment GROUP BY Site ORDER BY agency_premium DESC""")
    totals = query(f"""SELECT MEASURE(agency_cost) AS agency_cost,
        MEASURE(agency_premium) AS agency_premium, MEASURE(fill_rate) AS fill_rate
        FROM {CS}.mv_shift_fulfilment""")
    coverable = query(f"""SELECT COALESCE(SUM(saving_if_filled_internally),0) AS weekly_saving,
        COUNT(*) AS coverable_gaps FROM {CS}.vw_open_gaps WHERE ShiftDate <= current_date()+7""")
    absence = query(f"""SELECT ReasonGroup, MEASURE(absence_events) AS events,
        MEASURE(sickness_hours) AS sickness_hours FROM {CS}.mv_absence
        GROUP BY ReasonGroup ORDER BY events DESC""")
    return {"by_site": by_site, "totals": totals[0] if totals else {},
            "coverable": coverable[0] if coverable else {}, "absence": absence}


@router.post("/genie/ask")
def genie_ask(body: dict):
    """Proxy a question to the Genie space; return SQL + result rows."""
    q = body.get("question", "")
    if not GENIE_SPACE:
        raise HTTPException(400, "GENIE_SPACE_ID not configured")
    base = f"https://{HOST}/api/2.0/genie/spaces/{GENIE_SPACE}"
    hdr = {"Authorization": "Bearer " + _token(), "Content-Type": "application/json"}

    def call(method, path, payload=None):
        req = urllib.request.Request(base + path, data=json.dumps(payload).encode() if payload else None,
                                     headers=hdr, method=method)
        try:
            return json.loads(urllib.request.urlopen(req).read())
        except urllib.error.HTTPError as e:
            detail = e.read().decode(errors="replace")[:400]
            # The app runs as its own service principal. If that SP lacks CAN_RUN on the Genie
            # space the very first call 403s — previously an unhandled crash surfaced to the UI
            # as a bare "500 Internal Server Error" with no clue what to fix.
            if e.code in (401, 403):
                raise HTTPException(403,
                    "The app's service principal cannot run this Genie space. Grant it CAN_RUN on "
                    f"space {GENIE_SPACE}, then retry. (upstream {e.code}: {detail})") from None
            raise HTTPException(502, f"Genie API HTTP {e.code}: {detail}") from None

    start = call("POST", "/start-conversation", {"content": q})
    cid, mid = start.get("conversation_id"), start.get("message_id")
    if not cid or not mid:
        raise HTTPException(502, f"Genie did not return a conversation: {json.dumps(start)[:300]}")
    msg = {}
    for _ in range(30):
        msg = call("GET", f"/conversations/{cid}/messages/{mid}")
        if msg.get("status") in ("COMPLETED", "FAILED", "CANCELLED", "QUERY_RESULT_EXPIRED"):
            break
        time.sleep(3)
    sql_text, rows, cols = "", [], []
    for a in msg.get("attachments", []):
        if "query" in a:
            sql_text = a["query"].get("query", "")
            aid = a.get("attachment_id")
            try:
                res = call("GET", f"/conversations/{cid}/messages/{mid}/attachments/{aid}/query-result")
                sr = res.get("statement_response", {})
                cols = [c["name"] for c in sr.get("manifest", {}).get("schema", {}).get("columns", [])]
                rows = sr.get("result", {}).get("data_array", []) or []
            except Exception:
                pass
        if "text" in a and not sql_text:
            sql_text = a["text"].get("content", "")
    return {"status": msg.get("status"), "sql": sql_text, "columns": cols, "rows": rows[:100]}


# ---------- ACTION LAYER (what a dashboard/Genie cannot do) ----------

def _sql_lit(s):
    return "'" + str(s).replace("'", "''") + "'" if s is not None else "NULL"


# Columns of cover_decisions, in one place. Every write goes through _insert_decision so that
# adding a column can never silently misalign a positional INSERT (which is how the original
# three hand-built VALUES lists drifted).
_DECISION_COLS = ["decision_id", "HoursAssignmentID", "SiteName", "Grade", "ShiftDate",
                  "assigned_staff", "assigned_type", "distance_km", "saving_gbp", "rationale",
                  "decided_by", "decided_at", "status", "outreach_status", "resolution_mode",
                  "assigned_staff_number"]


def _decision_values(d: dict) -> str:
    """One VALUES tuple, ordered to match _DECISION_COLS."""
    def num(v):
        try:
            return str(float(v if v is not None else 0))
        except (TypeError, ValueError):
            return "0"
    return "(" + ", ".join([
        _sql_lit(d.get("decision_id") or str(uuid.uuid4())[:8]),
        str(int(d["HoursAssignmentID"])),
        _sql_lit(d.get("SiteName")), _sql_lit(d.get("Grade")),
        f"DATE'{d.get('ShiftDate')}'" if d.get("ShiftDate") else "NULL",
        _sql_lit(d.get("assigned_staff")), _sql_lit(d.get("assigned_type")),
        num(d.get("distance_km")), num(d.get("saving_gbp")),
        _sql_lit(d.get("rationale", "")), _sql_lit(d.get("decided_by", "ops-manager")),
        "current_timestamp()", _sql_lit(d.get("status", "ASSIGNED")),
        _sql_lit(d.get("outreach_status", "ACCEPTED")),
        _sql_lit(d.get("resolution_mode", "MANAGER")),
        _sql_lit(d.get("assigned_staff_number")),
    ]) + ")"


def _insert_decision(*rows: dict) -> str:
    cols = ", ".join(_DECISION_COLS)
    return (f"INSERT INTO {CS}.cover_decisions ({cols}) VALUES "
            + ", ".join(_decision_values(r) for r in rows))


@router.post("/assign")
def assign(body: dict):
    """Write-back: commit a cover decision, mark the gap resolved, bank the saving."""
    did = str(uuid.uuid4())[:8]
    query(_insert_decision({**body, "decision_id": did,
                            "status": "ASSIGNED", "outreach_status": "ACCEPTED",
                            "resolution_mode": body.get("resolution_mode", "MANAGER")}))
    return {"ok": True, "decision_id": did}


@router.post("/assign_bulk")
def assign_bulk(body: dict):
    """Commit a whole optimiser plan in ONE multi-row INSERT.

    The UI previously looped /assign once per gap (~129 sequential SQL round-trips,
    2+ minutes with the button stuck on 'Assigning…'). This collapses that to a
    single statement. Chunked so a very large plan can't blow the statement size."""
    plan = body.get("plan") or []
    if not plan:
        return {"ok": True, "committed": 0}
    rationale = body.get("rationale", "Automatic assignment")
    mode = body.get("resolution_mode", "AUTO")
    committed = 0
    CHUNK = 500
    for i in range(0, len(plan), CHUNK):
        chunk = [{**p, "assigned_staff": p.get("assigned_staff") or p.get("assign"),
                  "assigned_staff_number": p.get("assigned_staff_number") or p.get("StaffNumber"),
                  "assigned_type": p.get("assigned_type") or p.get("type"),
                  "saving_gbp": p.get("saving_gbp", p.get("saving")),
                  "rationale": rationale, "status": "ASSIGNED",
                  "outreach_status": "ACCEPTED", "resolution_mode": mode}
                 for p in plan[i:i + CHUNK]]
        query(_insert_decision(*chunk))
        committed += len(chunk)
    return {"ok": True, "committed": committed}


@router.get("/ledger")
def ledger():
    """Cumulative realized savings from decisions actually made in the app."""
    tot = query(f"""SELECT COALESCE(SUM(saving_gbp),0) AS total_saved, COUNT(*) AS shifts_covered
        FROM {CS}.cover_decisions WHERE status='ASSIGNED'""")
    recent = query(f"""SELECT decision_id, SiteName, Grade, ShiftDate, assigned_staff, assigned_type,
        saving_gbp, decided_at FROM {CS}.cover_decisions WHERE status='ASSIGNED'
        ORDER BY decided_at DESC LIMIT 20""")
    return {"totals": tot[0] if tot else {}, "recent": recent}


@router.post("/optimise")
def optimise(body: dict):
    """Whole-estate cover optimiser: across ALL open gaps at once, assign the best
    internal candidate under constraints (grade match, one-person-one-shift, no
    double-booking, prefer substantive over bank over none), greedily minimising
    agency spend. One set-based query builds every eligible gap<->candidate pair;
    the assignment is then resolved in-process. Returns a proposed plan for the
    manager to accept/override -- this is the action a dashboard/Genie cannot do."""
    days = int(body.get("days", 7))
    # ONE query: every eligible (gap, internal candidate) pair with distance + saving,
    # pre-ranked. Excludes agency candidates and already-committed gaps.
    pairs = query(f"""
        WITH g AS (
          SELECT HoursAssignmentID, SiteName, PersonGradeShortName AS Grade, CAST(ValidDate AS DATE) AS ShiftDate,
                 ShiftName, SiteLat, SiteLon, PlannedAgencyHours, AgencyHourlyRate, PermHourlyRate
          FROM {CS}.enriched_hoursassignment
          WHERE CAST(ValidDate AS DATE) BETWEEN current_date() AND current_date()+{days}
            AND FulfillmentStatusName='Unfilled'
            AND HoursAssignmentID NOT IN (SELECT HoursAssignmentID FROM {CS}.cover_decisions WHERE status='ASSIGNED')
        ),
        cand AS (
          SELECT DISTINCT StaffNumber, concat(Forenames,' ',Surname) Name, PersonGradeShortName Grade,
                 EmployeeTypeName EmployeeType, SiteLat lat, SiteLon lon
          FROM {CS}.enriched_hoursassignment WHERE StaffNumber IS NOT NULL AND EmployeeTypeName<>'Agency'
        ),
        worked AS (
          SELECT StaffNumber, SUM(WorkHours) h FROM {CS}.vwah_hoursassignment
          WHERE CAST(ValidDate AS DATE) BETWEEN current_date()-7 AND current_date() GROUP BY StaffNumber
        )
        SELECT g.HoursAssignmentID, g.SiteName, g.Grade, g.ShiftDate, g.ShiftName,
               c.StaffNumber, c.Name, c.EmployeeType,
               ROUND(6371*acos(least(1,cos(radians(g.SiteLat))*cos(radians(c.lat))*cos(radians(c.lon)-radians(g.SiteLon))+sin(radians(g.SiteLat))*sin(radians(c.lat)))),1) distance_km,
               coalesce(w.h,0) hours_last_7d,
               CASE c.EmployeeType WHEN 'Employee' THEN 1 WHEN 'Bank Only' THEN 2 ELSE 3 END contract_rank,
               ROUND(g.PlannedAgencyHours*(g.AgencyHourlyRate-g.PermHourlyRate),0) saving
        FROM g JOIN cand c ON c.Grade=g.Grade
        LEFT JOIN worked w ON c.StaffNumber=w.StaffNumber
        -- Working Time Directive, using the gap's real shift length. The optimiser previously had
        -- NO WTD filter, so it could propose a candidate the board itself would reject as non-compliant.
        WHERE (coalesce(w.h,0)+coalesce(g.PlannedAgencyHours,8)) <= 48
          AND c.StaffNumber NOT IN (
          SELECT StaffNumber FROM {CS}.vwah_hoursassignment
            WHERE CAST(ValidDate AS DATE)=g.ShiftDate AND FulfillmentStatusName<>'Unfilled' AND StaffNumber IS NOT NULL
          UNION SELECT StaffNumber FROM {CS}.vwah_unavailability
            WHERE UnavailabilityState='Approved' AND g.ShiftDate BETWEEN CAST(UnavailabilityStartDate AS DATE) AND CAST(UnavailabilityEndDate AS DATE)
        )
        ORDER BY saving DESC, distance_km ASC, contract_rank ASC, hours_last_7d ASC""")
    # greedy assignment: highest-value gaps first, one nurse per (staff, date)
    gap_ids = [g["HoursAssignmentID"] for g in query(f"""SELECT HoursAssignmentID FROM {CS}.vw_open_gaps
        WHERE ShiftDate BETWEEN current_date() AND current_date()+{days}
          AND HoursAssignmentID NOT IN (SELECT HoursAssignmentID FROM {CS}.cover_decisions WHERE status='ASSIGNED')""")]
    used_staff, filled, plan, total = set(), set(), [], 0.0
    for p in pairs:
        gid = p["HoursAssignmentID"]
        key = (p["StaffNumber"], str(p["ShiftDate"]))
        if gid in filled or key in used_staff:
            continue
        filled.add(gid); used_staff.add(key); total += _f(p["saving"])
        plan.append({"HoursAssignmentID": gid, "SiteName": p["SiteName"], "Grade": p["Grade"],
                     "ShiftDate": str(p["ShiftDate"]), "ShiftName": p["ShiftName"],
                     "assign": p["Name"], "assigned_staff": p["Name"],
                     "assigned_staff_number": p["StaffNumber"], "type": p["EmployeeType"],
                     "distance_km": _f(p["distance_km"]), "saving": _f(p["saving"])})
    return {"total_gaps": len(gap_ids), "assigned": len(plan), "unfilled": len(gap_ids) - len(plan),
            "total_saving": round(total), "plan": plan}


@router.get("/coworker/{gap_id}")
def coworker(gap_id: int):
    """AI co-worker: recommend the best cover with plain-English rationale + drafted
    shift-offer message. Runs LIVE in-geo via real-time serving (gpt-oss-120b)."""
    g = query(f"""SELECT HoursAssignmentID, SiteName, Grade, GradeName, ShiftDate, ShiftName, GapReason,
        agency_cost_if_unfilled FROM {CS}.vw_open_gaps WHERE HoursAssignmentID={int(gap_id)}""")
    if not g:
        raise HTTPException(404, "gap not found")
    g = g[0]
    cands = query(f"SELECT * FROM {CS}.fn_find_replacements({int(gap_id)})")[:5]
    prompt = f"""You are a nurse-rostering co-worker for a Ramsay hospital. A shift needs cover:
Site: {g['SiteName']}, Grade: {g['GradeName']} ({g['Grade']}), Date: {g['ShiftDate']}, Shift: {g['ShiftName']}, Reason: {g['GapReason']}.
If unfilled it costs ~£{_f(g['agency_cost_if_unfilled']):.0f} in agency. Candidates (ranked):
{json.dumps([{ 'name':c['Name'],'type':c['EmployeeType'],'distance_km':c['distance_km'],'hours_last_7d':c['hours_last_7d'],'saving_vs_agency':c['saving_vs_agency']} for c in cands], indent=1)}
Recommend ONE candidate. Consider proximity, contract type (prefer substantive Employee over Bank over Agency), fatigue (hours last 7 days), and cost saved. Respond as JSON only: {{"recommend":"<name>","reason":"<one sentence>","risk":"<any risk or 'none'>","offer_message":"<short SMS to the nurse offering the shift>"}}"""
    try:
        H2 = HOST if HOST.startswith("http") else "https://" + HOST
        req = urllib.request.Request(f"{H2}/serving-endpoints/{COWORKER_MODEL}/invocations",
            data=json.dumps({"messages": [{"role": "user", "content": prompt}], "max_tokens": 500, "temperature": 0.2}).encode(),
            headers={"Authorization": "Bearer " + _token(), "Content-Type": "application/json"}, method="POST")
        resp = json.loads(urllib.request.urlopen(req, timeout=60).read())
        msg = resp.get("choices", [{}])[0].get("message", {})
        content = msg.get("content", "")
        if isinstance(content, list):  # reasoning models return blocks
            content = " ".join(b.get("text", "") for b in content if isinstance(b, dict))
        rec = None
        try:
            s = content[content.index("{"):content.rindex("}") + 1]
            rec = json.loads(s)
        except Exception:
            rec = {"recommend": cands[0]["Name"] if cands else None, "reason": content[:200], "risk": "n/a", "offer_message": ""}
        return {"gap": g, "candidates": cands, "recommendation": rec, "model": COWORKER_MODEL}
    except Exception as e:
        # graceful fallback: rule-based recommendation if serving unavailable
        top = cands[0] if cands else None
        return {"gap": g, "candidates": cands, "model": "rule-based-fallback",
                "recommendation": {"recommend": top["Name"] if top else None,
                    "reason": f"Nearest available {g['Grade']} ({top['distance_km']}km), {top['EmployeeType']}, saves £{_f(top['saving_vs_agency']):.0f} vs agency." if top else "No internal candidate.",
                    "risk": "none" if top else "agency required",
                    "offer_message": f"Hi {top['Name'].split()[0]}, can you cover a {g['Grade']} shift at {g['SiteName']} on {g['ShiftDate']} ({g['ShiftName']})? Please confirm." if top else ""},
                "error": str(e)[:120]}
