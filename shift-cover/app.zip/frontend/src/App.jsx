import React, { useState, useEffect } from 'react'

const NAVY = '#0b2545', ACCENT = '#1f6feb', GOOD = '#2e7d32', WARN = '#c62828', GOLD = '#b8860b', GREY = '#667'
const api = (p, o) => fetch('/api' + p, o).then(async r => {
  if (!r.ok) {
    // Prefer the server's {"error": ...} detail — a bare "500 Internal Server Error" is
    // undebuggable from the browser.
    const body = await r.text()
    let detail = body.slice(0, 300)
    try { detail = JSON.parse(body).error || detail } catch { /* not JSON */ }
    throw new Error(`${r.status} — ${detail}`)
  }
  return r.json()
})
const ErrBox = ({ msg, onRetry }) => (
  <div style={{ background: '#fdecea', border: `1px solid ${WARN}`, borderRadius: 8, padding: 12, fontSize: 13, color: '#7f1d1d' }}>
    <b>Something went wrong.</b> {msg}
    {onRetry && <button onClick={onRetry} style={{ marginLeft: 10, fontSize: 12, background: WARN, color: '#fff', border: 0, borderRadius: 6, padding: '4px 10px', cursor: 'pointer' }}>Retry</button>}
  </div>
)
const short = s => (s || '').replace('Ramsay ', '').replace(' Hospital', '')

// "2026-08-29" -> "Fri 29 Aug". Parsed as a plain date, NOT via new Date(str) on a full
// timestamp, so the label can never slide a day on a timezone boundary.
const fmtDate = s => {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || '')
  if (!m) return s || ''
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]))
  return d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })
}
// "2026-08-29 20:00:00" -> "20:00"
const fmtTime = s => {
  const m = /(\d{2}):(\d{2})/.exec(s || '')
  return m ? `${m[1]}:${m[2]}` : ''
}
// "Night 20:00–08:00 (12h)". Falls back to the raw ShiftName if the timestamps are absent,
// so a card degrades to the old label rather than rendering an empty line.
const fmtShift = g => {
  const a = fmtTime(g.ShiftStartDate), b = fmtTime(g.ShiftEndDate)
  const span = a && b ? `${a}–${b}` : (g.ShiftName || '')
  const hrs = g.shift_hours ? ` (${g.shift_hours % 1 === 0 ? g.shift_hours : g.shift_hours.toFixed(1)}h)` : ''
  return [g.ShiftType, span].filter(Boolean).join(' ') + hrs
}
const SHOW_MAX = 60   // max position cards mounted at once (see render cap in PositionsBoard)
// Genie space, opened directly so it runs as the signed-in user (no app-SP grant needed).
const GENIE_URL = 'https://adb-7405610211988135.15.azuredatabricks.net/genie/rooms/01f19b8fda6e1045ba3a1e5b257e8ee3'
const DASHBOARD_URL = 'https://adb-7405610211988135.15.azuredatabricks.net/dashboardsv3/01f19bd246921cbe8304fb2b706760a9/pages'

const Card = ({ children, style }) => (
  <div style={{ background: '#fff', borderRadius: 10, boxShadow: '0 1px 4px rgba(0,0,0,.1)', padding: 18, ...style }}>{children}</div>
)
// Contract-type marker. "Substantive" was jargon on every single row, so it is gone [L1];
// contract type still drives ranking server-side [L4], it just stops shouting. Only "Bank"
// is worth a marker — it is the exception a manager should notice (Ramsay's internal
// flexible pool, no fixed hours, slight premium) [L2]. Agency staff are excluded from
// candidates by design and must never appear as an option [L3].
const Badge = ({ t }) => {
  if (t === 'Bank Only') {
    return <span title="Ramsay's internal flexible pool — own staff, no fixed hours"
      style={{ background: '#eef4ff', color: ACCENT, border: `1px solid ${ACCENT}`, borderRadius: 12, padding: '1px 8px', fontSize: 11, fontWeight: 600 }}>Bank</span>
  }
  if (t === 'Employee') return null
  // Anything else (incl. Agency, which should never reach a candidate row) stays visible
  // rather than being silently swallowed — an unexpected value is worth seeing.
  return t ? <span style={{ background: WARN, color: '#fff', borderRadius: 12, padding: '1px 8px', fontSize: 11, fontWeight: 600 }}>{t}</span> : null
}
function Kpi({ label, value, sub, color }) {
  return <Card style={{ flex: 1, minWidth: 170 }}>
    <div style={{ fontSize: 13, color: GREY }}>{label}</div>
    <div style={{ fontSize: 28, fontWeight: 700, color: color || NAVY, marginTop: 4 }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: '#889', marginTop: 2 }}>{sub}</div>}
  </Card>
}

// Style objects hoisted out of render. Rebuilding these inline on every render gives every
// node a new props identity and forces full reconciliation across ~1,200 option rows.
const S = {
  toolbar: { display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' },
  input: { flex: 1, minWidth: 200, padding: '8px 10px', border: '1px solid #ccd', borderRadius: 6, fontSize: 13 },
  select: { padding: '8px 10px', border: '1px solid #ccd', borderRadius: 6, fontSize: 13, background: '#fff' },
  chkWrap: { display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: '#445', cursor: 'pointer' },
  linkBtn: { background: 'none', border: 0, color: ACCENT, fontSize: 13, fontWeight: 600, cursor: 'pointer', padding: '6px 4px' },
  smallBtn: { fontSize: 12, background: '#eef2f8', color: '#445', border: 0, borderRadius: 6, padding: '6px 10px', cursor: 'pointer' },
  cardHead: { display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap', cursor: 'pointer' },
  headText: { minWidth: 210 },
  h1: { fontWeight: 700, color: NAVY },
  h2: { fontSize: 12, color: '#445' },
  h3: { fontSize: 12, color: GREY },
  optWrap: { marginTop: 10, display: 'grid', gap: 8 },
  optRow: { display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap', border: '1px solid #eee', borderRadius: 8, padding: '8px 12px' },
  name: { fontWeight: 600, minWidth: 130 },
  staffNo: { fontWeight: 400, fontSize: 11, color: GREY, marginLeft: 5 },
  meta: { fontSize: 12, color: GREY },
  spacer: { flex: 1 },
  agencyNote: { marginTop: 10, fontSize: 13, color: GOLD, background: '#fffaf0', borderRadius: 6, padding: 8 },
  chev: { fontSize: 12, color: GREY, width: 16, textAlign: 'center' },
  countPill: { fontSize: 11, fontWeight: 600, color: '#445', background: '#eef2f8', borderRadius: 10, padding: '2px 9px' },
  agencyPill: { fontSize: 11, fontWeight: 600, color: GOLD, background: '#fffaf0', border: `1px solid ${GOLD}`, borderRadius: 10, padding: '2px 9px' },
  btnReach: { fontSize: 12, background: GOLD, color: '#fff', border: 0, borderRadius: 6, padding: '5px 10px', cursor: 'pointer' },
  btnAccept: { fontSize: 12, background: GOOD, color: '#fff', border: 0, borderRadius: 6, padding: '5px 10px', cursor: 'pointer' },
  btnDecline: { fontSize: 12, background: '#fff', color: WARN, border: `1px solid ${WARN}`, borderRadius: 6, padding: '5px 10px', cursor: 'pointer' },
}
const OPT_BG = { ACCEPTED: '#f4fbf6', DECLINED: '#fdf6f5' }
const ALL = 'All'

// Outreach marker pill for an option
function Outreach({ state }) {
  const map = {
    NONE: { t: 'Not contacted', bg: '#eee', fg: GREY },
    REACHED_OUT: { t: '📤 Reached out', bg: '#fff4e0', fg: GOLD },
    OFFERED: { t: '📤 Reached out', bg: '#fff4e0', fg: GOLD },
    ACCEPTED: { t: '✓ Accepted', bg: '#e6f4ea', fg: GOOD },
    DECLINED: { t: '✗ Declined', bg: '#fdecea', fg: WARN },
  }
  const m = map[state] || map.NONE
  return <span style={{ background: m.bg, color: m.fg, borderRadius: 10, padding: '2px 9px', fontSize: 11, fontWeight: 600 }}>{m.t}</span>
}

// ---------- MAIN: Positions to fill ----------
function PositionsBoard({ onChanged, refresh }) {
  const [days, setDays] = useState(7)
  const [data, setData] = useState(null); const [loading, setLoading] = useState(true)
  const [err, setErr] = useState(null)

  // Collapsed by default [C1]. A Set of HoursAssignmentID — keyed on identity, not array
  // index, so expansion survives a data refresh that reorders the list [C6].
  const [expanded, setExpanded] = useState(() => new Set())
  // Optimistic outreach [R1][R2]. Keyed `gapId-staffNumber` (StaffNumber, never name — 108
  // names are shared here). Lives at board level, so it also survives collapse/expand [C7].
  const [overrides, setOverrides] = useState({})

  // Filters. `q` is what the user types; `qDeb` is the debounced value the list actually
  // filters on [R6], so typing never re-filters ~1,800 gaps per keystroke.
  const [q, setQ] = useState(''); const [qDeb, setQDeb] = useState('')
  const [site, setSite] = useState(ALL), [grade, setGrade] = useState(ALL)
  const [ward, setWard] = useState(ALL), [noCover, setNoCover] = useState(false)
  useEffect(() => {
    const t = setTimeout(() => setQDeb(q), 200)
    return () => clearTimeout(t)
  }, [q])

  const load = () => {
    setLoading(true); setErr(null)
    api(`/board?days=${days}`).then(d => { setData(d); setLoading(false) })
      .catch(e => { setErr(e.message); setLoading(false) })
  }
  useEffect(load, [days, refresh])

  const gaps = data && Array.isArray(data.gaps) ? data.gaps : []

  // Dropdown values derived from the returned rows, never hard-coded [F6] — a literal list
  // would silently drift from the data the moment a site or ward is added.
  const opts = React.useMemo(() => {
    const u = k => [ALL, ...[...new Set(gaps.map(g => g[k]).filter(Boolean))].sort()]
    return { sites: u('SiteName'), grades: u('Grade'), wards: u('Ward') }
  }, [gaps])

  // Apply the current outreach override on top of the server value, so filtering and
  // rendering agree on one state.
  const outreachOf = (g, o) => overrides[`${g.HoursAssignmentID}-${o.staff}`] ?? o.outreach

  // Filter FIRST, then cap, then count [F10]. KPIs are computed from this array, never from
  // the unfiltered one — a KPI that ignores the filter actively misleads.
  const filtered = React.useMemo(() => {
    const needle = qDeb.trim().toLowerCase()
    return gaps.filter(g => {
      if (site !== ALL && g.SiteName !== site) return false
      if (grade !== ALL && g.Grade !== grade) return false
      if (ward !== ALL && g.Ward !== ward) return false
      if (noCover && g.has_internal) return false
      // Person search matches a candidate's NAME or STAFF NUMBER, keeping any gap that
      // person could cover [F1].
      if (needle) {
        const hit = (g.options || []).some(o =>
          (o.name || '').toLowerCase().includes(needle) ||
          (o.staff || '').toLowerCase().includes(needle))
        if (!hit) return false
      }
      return true
    })
  }, [gaps, qDeb, site, grade, ward, noCover])

  const anyFilter = qDeb.trim() !== '' || site !== ALL || grade !== ALL || ward !== ALL || noCover
  const clearFilters = () => { setQ(''); setQDeb(''); setSite(ALL); setGrade(ALL); setWard(ALL); setNoCover(false) }

  const shown = filtered.slice(0, SHOW_MAX)
  const toggle = id => setExpanded(prev => {
    const n = new Set(prev)
    n.has(id) ? n.delete(id) : n.add(id)
    return n
  })
  // Expand/collapse all operate on the VISIBLE list, which is what the user can see [C4].
  const expandAll = () => setExpanded(new Set(shown.filter(g => g.has_internal).map(g => g.HoursAssignmentID)))
  const collapseAll = () => setExpanded(new Set())

  // Optimistic outreach [R1][R2][R3][R4].
  //
  // This used to end `.then(() => { onChanged(); load() })`, so one click re-ran the ENTIRE
  // /board query and re-rendered every card just to flip one pill — multi-second stall on the
  // core loop, paid twice for "Reach out" then "Declined".
  //
  // Now: flip local state immediately, POST in the background, and on failure REVERT the pill
  // AND surface the error [R4]. Both, always. A pill left reading "Called" after a failed
  // write tells a manager someone was contacted when nothing was logged — worse than the lag
  // it replaced. Deliberately NOT debounced or batched: the write must still hit the server
  // per click because two managers can work the same list and the outreach log is the shared
  // record. Only the UI feedback is made instant.
  const reach = (g, o, reply) => {
    const key = `${g.HoursAssignmentID}-${o.staff}`
    const prev = overrides[key]                 // may be undefined = "fall back to server value"
    setErr(null)
    setOverrides(m => ({ ...m, [key]: reply }))  // instant, before any network work
    api('/outreach', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      // staff_number is what the backend keys outreach state on — names are not unique
      body: JSON.stringify({ HoursAssignmentID: g.HoursAssignmentID, staff_name: o.name, staff_number: o.staff, reply,
        SiteName: g.SiteName, Grade: g.Grade, ShiftDate: g.ShiftDate, assigned_type: o.type,
        distance_km: o.distance_km, saving_gbp: o.saving }) })
      // No load() on the success path [R3]; the server is source of truth on the next
      // natural refresh. onChanged() is also dropped here — it bumps a parent counter that
      // refreshes sibling tabs, re-running this query a second time.
      .catch(e => {
        setOverrides(m => {
          const n = { ...m }
          if (prev === undefined) delete n[key]; else n[key] = prev
          return n
        })
        setErr(`Could not record that outreach for ${o.name} (${o.staff}) — nothing was logged. ${e.message}`)
      })
  }

  return <div style={{ display: 'grid', gap: 14 }}>
    <Card>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap' }}>
        <div style={{ flex: 1, minWidth: 240 }}>
          <h3 style={{ margin: 0, color: NAVY }}>Positions to fill</h3>
          <div style={{ fontSize: 13, color: GREY }}>Every unfilled shift in the window, with the best internal cover options and who's been contacted.</div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          {[7, 10, 30].map(d => <button key={d} onClick={() => setDays(d)}
            style={{ background: days === d ? NAVY : '#eef2f8', color: days === d ? '#fff' : '#445', border: 0, borderRadius: 6, padding: '8px 14px', fontWeight: 600, cursor: 'pointer' }}>Next {d} days</button>)}
        </div>
      </div>

      {/* Filter toolbar [F1]-[F8]. Dropdown values come from the returned rows [F6]. */}
      <div style={{ marginTop: 14, paddingTop: 14, borderTop: '1px solid #eee', display: 'grid', gap: 10 }}>
        <div style={S.toolbar}>
          <input value={q} onChange={e => setQ(e.target.value)} style={S.input}
                 placeholder="🔍 Person or staff # — finds gaps they could cover" />
          <select value={site} onChange={e => setSite(e.target.value)} style={S.select} aria-label="Hospital">
            {opts.sites.map(v => <option key={v} value={v}>{v === ALL ? 'Hospital: All' : short(v)}</option>)}
          </select>
          <select value={grade} onChange={e => setGrade(e.target.value)} style={S.select} aria-label="Grade">
            {opts.grades.map(v => <option key={v} value={v}>{v === ALL ? 'Grade: All' : v}</option>)}
          </select>
          <select value={ward} onChange={e => setWard(e.target.value)} style={S.select} aria-label="Ward">
            {opts.wards.map(v => <option key={v} value={v}>{v === ALL ? 'Ward: All' : v}</option>)}
          </select>
        </div>
        <div style={S.toolbar}>
          <label style={S.chkWrap}>
            <input type="checkbox" checked={noCover} onChange={e => setNoCover(e.target.checked)} />
            Only gaps with no internal cover
          </label>
          <button onClick={clearFilters} style={S.linkBtn}>Clear filters</button>
          <div style={S.spacer} />
          <button onClick={expandAll} style={S.smallBtn}>Expand all</button>
          <button onClick={collapseAll} style={S.smallBtn}>Collapse all</button>
        </div>
      </div>
    </Card>

    {/* Order matters: err and the null-data guard MUST come before any data.* dereference.
        Previously a failed fetch left loading=false with data=null, so `data.gaps.length`
        threw and React unmounted the whole tree — the app "blanked out". */}
    {err ? <ErrBox msg={err} onRetry={load} /> :
      loading ? <Card>Loading positions…</Card> :
      !data || !Array.isArray(data.gaps) ? <ErrBox msg="No data returned from the server." onRetry={load} /> :
      data.gaps.length === 0 ? <Card><p style={{ color: GOOD, fontWeight: 600 }}>✓ No open positions in the next {days} days — all shifts covered.</p></Card> :
      <>
        {/* KPIs reflect the FILTERED set and say so [F10]. Showing an unfiltered 93 next to a
            one-hospital list is actively misleading — you'd read another site's count. */}
        <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
          <Kpi label={anyFilter ? `Open positions (matching, ${days}d)` : `Open positions (${days}d)`}
               value={filtered.length} color={WARN}
               sub={anyFilter ? `filtered from ${gaps.length}` : null} />
          <Kpi label="Coverable internally" value={filtered.filter(g => g.has_internal).length} color={GOOD} sub="have ≥1 option" />
          <Kpi label="Need agency (no internal)" value={filtered.filter(g => !g.has_internal).length} color={GOLD} />
        </div>
        {/* Render cap. Collapse-by-default already removes ~1,200 option rows; this keeps the
            card COUNT sane on the 30-day window (1,801 gaps). Counting rule is
            filter -> cap -> count, and the label states all three numbers. */}
        {filtered.length > SHOW_MAX && <Card style={{ padding: 12, fontSize: 13, color: GREY }}>
          Showing <b>{Math.min(SHOW_MAX, filtered.length)}</b> of <b>{filtered.length}</b>
          {anyFilter ? <> matching · filtered from <b>{gaps.length}</b></> : <> in this window</>},
          highest agency cost first. Narrow the filters to work the full list.
        </Card>}
        {/* An empty result must say so explicitly, never render as a blank page [F9]. */}
        {filtered.length === 0 && <Card>
          <p style={{ margin: 0, fontWeight: 600, color: NAVY }}>No positions match these filters.</p>
          <p style={{ margin: '6px 0 0', fontSize: 13, color: GREY }}>
            {gaps.length} open position{gaps.length === 1 ? '' : 's'} in the next {days} days.
            <button onClick={clearFilters} style={{ ...S.linkBtn, marginLeft: 6 }}>Clear filters</button>
          </p>
        </Card>}
        {shown.map(g => {
          const open = expanded.has(g.HoursAssignmentID)
          const n = g.options.length
          return (
          <Card key={g.HoursAssignmentID} style={{ padding: 14 }} data-gap={g.HoursAssignmentID}>
            {/* Agency-required rows carry nothing to reveal, so the header is not a control [C3]. */}
            <div style={n ? S.cardHead : { ...S.cardHead, cursor: 'default' }}
                 onClick={n ? () => toggle(g.HoursAssignmentID) : undefined}>
              <span style={S.chev}>{n ? (open ? '▾' : '▸') : ''}</span>
              <div style={S.headText}>
                {/* Position in full words — "Head of Clinical Services", not "HOC". [H3] */}
                <div style={S.h1}>1× {g.PersonGradeLongName || g.GradeName || g.Grade} needed</div>
                {/* Ward is the first thing a manager asks. 100% populated, so a blank is a bug. [H4] */}
                <div style={S.h2}>{short(g.SiteName)}{g.Ward ? ` · ${g.Ward}` : ''}</div>
                <div style={S.h3}>{fmtDate(g.ShiftDate)} · {fmtShift(g)}</div>
                {/* Why there is no name — or, where the roster genuinely has one, who is away.
                    An "Unfilled" row is a vacant roster post that was never assigned to anybody,
                    so there is nobody to name and we do NOT guess: matching site+grade+date gives
                    2.15 candidate absences per shift (worst 9). A name appears ONLY when the
                    roster itself carries that person's StaffNumber. [H6][H7] */}
                {g.is_unfilled
                  ? <div style={{ fontSize: 12, color: '#556' }}>Unfilled post on the roster — no named absence</div>
                  : <div style={{ fontSize: 12, color: WARN }}>
                      Covering: {g.absent_staff_name}
                      <span style={{ color: GREY, marginLeft: 4 }}>({g.absent_staff_number})</span>
                      {' '}— {(g.absence_reason_group === 'Sickness' ? 'off sick' : 'on leave')}
                    </div>}
              </div>
              <div style={S.spacer} />
              {/* A collapsed row must still say whether it is actionable [C2]. */}
              {n ? <span style={S.countPill}>{n} option{n === 1 ? '' : 's'}</span>
                 : <span style={S.agencyPill}>⚠ agency</span>}
            </div>

            {/* Option rows are CONDITIONALLY MOUNTED, not hidden with CSS [C5] — that is where
                the performance win comes from. The 30-day window would otherwise mount ~1,200
                option rows at once. */}
            {n === 0 ? (
              <div style={S.agencyNote}>⚠ No compliant internal cover (grade + Working-Time-Directive). Agency required.</div>
            ) : open ? (
              <div style={S.optWrap}>
                {g.options.map(o => {
                  const st = outreachOf(g, o)
                  return (
                  /* key must be unique across the WHOLE list, not just within a gap — rank is
                     only 1..3 and repeats for every gap, which lets React reuse DOM nodes and
                     bleed outreach button state between different positions. */
                  <div key={`${g.HoursAssignmentID}-${o.staff}-${o.rank}`}
                       style={{ ...S.optRow, background: OPT_BG[st] || '#fafbfc' }}>
                    <span style={{ fontSize: 12, fontWeight: 700, color: '#fff', background: o.rank === 1 ? GOOD : o.rank === 2 ? ACCENT : GREY, borderRadius: '50%', width: 22, height: 22, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>{o.rank}</span>
                    {/* StaffNumber shown because names are NOT unique (108 shared names in the estate) —
                        without it the board looks like it double-books one nurse across two sites. */}
                    <span style={S.name}>{o.name}
                      <span style={S.staffNo}>{o.staff}</span>
                    </span>
                    <Badge t={o.type} />
                    <span style={S.meta}>{o.distance_km} km · {o.hours_last_7d}h this wk</span>
                    <div style={S.spacer} />
                    <Outreach state={st} />
                    {st === 'NONE' &&
                      <button onClick={() => reach(g, o, 'REACHED_OUT')} style={S.btnReach}>Reach out</button>}
                    {(st === 'REACHED_OUT' || st === 'OFFERED') && <>
                      <button onClick={() => reach(g, o, 'ACCEPTED')} style={S.btnAccept}>Mark accepted</button>
                      <button onClick={() => reach(g, o, 'DECLINED')} style={S.btnDecline}>Declined</button>
                    </>}
                  </div>)
                })}
              </div>
            ) : null}
          </Card>)
        })}
      </>}
  </div>
}

// ---------- Ask Genie (launches the Genie space directly) ----------
// Deliberately NOT an embedded proxy. The in-app proxy called Genie as the app's service
// principal, which needs a CAN_RUN grant that keeps getting lost when the workspace is
// recreated — and a missing grant surfaced as an opaque 500 mid-demo. Opening the space in a
// new tab runs as the SIGNED-IN USER, so it needs no extra grant and shows the full native
// Genie experience (follow-ups, SQL, charts) instead of a cut-down table.
function GeniePanel() {
  const samples = [
    'Which grade has the most unfilled shifts?',
    'How much agency premium by hospital?',
    'How many nurses are off sick this week?',
    'Who can cover the most expensive open shift?',
  ]
  return <Card>
    <h3 style={{ margin: '0 0 6px', color: NAVY }}>Ask Genie</h3>
    <p style={{ margin: '0 0 14px', fontSize: 13, color: GREY, maxWidth: 720 }}>
      Ask questions of the workforce data in plain English — open positions, agency cost,
      absence, and who is available to cover. Opens in a new tab and runs as you.
    </p>
    <a href={GENIE_URL} target="_blank" rel="noopener noreferrer"
       style={{ display: 'inline-block', background: ACCENT, color: '#fff', textDecoration: 'none',
                borderRadius: 8, padding: '11px 20px', fontSize: 14, fontWeight: 700 }}>
      🔎 Open Genie — Ramsay Workforce ↗
    </a>
    <div style={{ marginTop: 18, fontSize: 12, color: GREY }}>Try asking:</div>
    <ul style={{ margin: '6px 0 0', paddingLeft: 18, fontSize: 13, color: '#445', lineHeight: 1.7 }}>
      {samples.map(s => <li key={s}>{s}</li>)}
    </ul>
    <div style={{ marginTop: 20, paddingTop: 14, borderTop: '1px solid #eee', fontSize: 13, color: GREY }}>
      Prefer a curated view? <a href={DASHBOARD_URL} target="_blank" rel="noopener noreferrer"
        style={{ color: ACCENT, fontWeight: 600 }}>Open the executive dashboard ↗</a>
      {' '}— estate agency spend, premium by hospital, absence and fill rate.
    </div>
  </Card>
}

// Last line of defence: any render exception below this shows a message instead of a white
// screen. React unmounts the entire tree on an uncaught render error — which is exactly how
// this app "blanked out" — so the demo must never depend on every component being defensive.
class ErrorBoundary extends React.Component {
  constructor(p) { super(p); this.state = { error: null } }
  static getDerivedStateFromError(error) { return { error } }
  componentDidCatch(error, info) { console.error('App render error:', error, info) }
  render() {
    if (!this.state.error) return this.props.children
    return <div style={{ padding: 20 }}>
      <ErrBox msg={`Display error: ${this.state.error.message}. The data is safe — reload to continue.`}
              onRetry={() => { this.setState({ error: null }); location.reload() }} />
    </div>
  }
}

export default function App() {
  const [tab, setTab] = useState('positions'); const [rev, setRev] = useState(0)
  const bump = () => setRev(r => r + 1)
  const tabs = [['positions', '🗂 Positions to fill'], ['genie', '🔎 Ask Genie']]
  return <div style={{ fontFamily: 'system-ui, sans-serif', background: '#f4f6f9', minHeight: '100vh' }}>
    <div style={{ background: NAVY, color: '#fff', padding: '14px 24px', display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
      <b style={{ fontSize: 18 }}>Ramsay Shift Cover</b>
      <span style={{ fontSize: 13, opacity: .8 }}>Fill open positions — find internal cover and reach out</span>
      <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
        {tabs.map(([k, l]) => <button key={k} onClick={() => setTab(k)}
          style={{ background: tab === k ? ACCENT : 'transparent', color: '#fff', border: '1px solid rgba(255,255,255,.3)', borderRadius: 6, padding: '6px 14px', cursor: 'pointer' }}>{l}</button>)}
      </div>
    </div>
    <div style={{ padding: 20 }}>
      <ErrorBoundary key={tab}>
        {tab === 'positions' && <PositionsBoard onChanged={bump} refresh={rev} />}
        {tab === 'genie' && <GeniePanel />}
      </ErrorBoundary>
    </div>
  </div>
}
