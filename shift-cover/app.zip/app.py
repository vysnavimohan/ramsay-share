import os, logging, traceback
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from server.routes import data

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("ramsay")

app = FastAPI(title="Ramsay Shift Cover")
app.include_router(data.router, prefix="/api")


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    """Return the REAL error to the UI and log the traceback.

    Without this, any unhandled exception became a bare "500 Internal Server Error" with no
    detail — nothing to debug from the browser, and app /logz needs interactive OAuth so
    server logs are awkward to reach."""
    log.error("Unhandled error on %s\n%s", request.url.path, traceback.format_exc())
    return JSONResponse(status_code=500,
                        content={"error": f"{type(exc).__name__}: {str(exc)[:600]}",
                                 "diagnosis": _diagnose(str(exc)),
                                 "path": request.url.path})


@app.get("/api/health")
def health():
    """Cheap end-to-end probe: confirms env + a warehouse round-trip without running the
    heavy board query. Hit this first when the UI misbehaves."""
    out = {"env": {k: bool(os.environ.get(k)) for k in
                   ("WAREHOUSE_ID", "CATALOG_SCHEMA", "GENIE_SPACE_ID", "DATABRICKS_TOKEN")}}
    try:
        from server.db import query
        out["warehouse"] = query("SELECT 1 AS ok")[0]
        out["catalog_schema"] = os.environ.get("CATALOG_SCHEMA")
        out["ok"] = True
    except Exception as e:
        out["ok"] = False
        out["error"] = f"{type(e).__name__}: {str(e)[:400]}"
        out["diagnosis"] = _diagnose(str(e))
    return out


def _diagnose(msg: str) -> str | None:
    """Turn the two failures that have actually bitten us into an instruction, not a stack trace."""
    # A recreated Databricks App gets a NEW service principal, and the warehouse grant does not
    # follow it — so every query 403s and the app looks broken rather than unauthorised.
    if "PERMISSION_DENIED" in msg and "warehouse" in msg:
        return (f"This app's service principal lacks CAN_USE on warehouse "
                f"{os.environ.get('WAREHOUSE_ID')}. Fix: SQL Warehouses > that warehouse > "
                f"Permissions > add this app's service principal > Can use. "
                f"NOTE: recreating the app mints a new service principal, so this grant must be "
                f"re-applied after every recreate.")
    if "PERMISSION_DENIED" in msg or "does not have" in msg:
        return (f"Permission denied reading {os.environ.get('CATALOG_SCHEMA')}. The app's service "
                f"principal needs SELECT on the views and EXECUTE on the functions.")
    if "TABLE_OR_VIEW_NOT_FOUND" in msg or "RESOURCE_DOES_NOT_EXIST" in msg:
        return (f"A required object is missing from {os.environ.get('CATALOG_SCHEMA')}. "
                f"Re-run the build scripts in build/ to recreate the views.")
    return None

_dist = os.path.join(os.path.dirname(__file__), "frontend", "dist")
if os.path.exists(_dist):
    app.mount("/assets", StaticFiles(directory=os.path.join(_dist, "assets")), name="assets")
    @app.get("/{full_path:path}")
    async def spa(full_path: str):
        return FileResponse(os.path.join(_dist, "index.html"))
