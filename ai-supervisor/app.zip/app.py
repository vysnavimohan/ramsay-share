"""FastAPI entry point for the Ramsay AI Operations Supervisor app.

- SSE streaming of the multi-stage supervisor trace + final answer/chart.
- Lakebase-backed conversation history + trace persistence (replayable).
- Serves the pre-built React frontend from frontend/dist.
"""
import asyncio
import json
import os
import uuid
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.responses import StreamingResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from pydantic import BaseModel

from server.config import SPACES
from server import db
from server import analytics
from server import cache
from server.supervisor import run_supervisor


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    # Pre-warm the 4 Genie spaces so the first live demo question is fast (SPEC §3.9).
    # Best-effort, non-blocking: fire and forget.
    asyncio.create_task(cache.prewarm_spaces())
    yield


app = FastAPI(title="Ramsay AI Operations Supervisor", lifespan=lifespan)


@app.get("/api/health")
def health():
    return {"status": "ok", "demoMode": db.is_demo(),
            "spaces": {k: {"label": v["label"], "desc": v["desc"]} for k, v in SPACES.items()}}


@app.get("/api/shift/options")
def shift_options():
    return analytics.options()


class ShiftRequest(BaseModel):
    sources: list[str] = []
    targets: list[str] = []
    procedures: list[str] = []
    pct: float = 10.0
    dateFrom: str | None = None
    dateTo: str | None = None
    useAverage: bool = True


@app.post("/api/shift/compute")
def shift_compute(req: ShiftRequest):
    if not req.sources or not req.targets or not req.procedures:
        return JSONResponse({"error": "Select at least one source, target and procedure."}, status_code=400)
    try:
        res = analytics.compute_shift(
            req.sources, req.targets, req.procedures, req.pct,
            req.dateFrom, req.dateTo, req.useAverage)
        res["narrative"] = analytics.shift_narrative(req.sources, req.targets, req.procedures, req.pct)
        return res
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@app.get("/api/forecast")
def forecast(sites: str = ""):
    site_list = [s for s in sites.split(",") if s] if sites else None
    try:
        return analytics.forecast(site_list)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@app.get("/api/conversations")
def conversations():
    return db.list_conversations()


@app.get("/api/conversations/{cid}")
def conversation(cid: str):
    return db.get_transcript(cid)


@app.get("/api/chat/stream")
async def chat_stream(q: str = "", c: str = ""):
    question = (q or "").strip()
    conversation_id = c or str(uuid.uuid4())
    if not question:
        return JSONResponse({"error": "Missing question"}, status_code=400)

    async def gen():
        loop = asyncio.get_event_loop()
        queue: asyncio.Queue = asyncio.Queue()
        turn_id = str(uuid.uuid4())
        events: list = []

        def emit(event):
            events.append(event)
            loop.call_soon_threadsafe(queue.put_nowait, event)

        def sse(event):
            return f"data: {json.dumps(event, default=str)}\n\n"

        yield sse({"stage": "meta", "conversationId": conversation_id})

        # Persist user message + create/update conversation.
        title = question[:80]
        db.upsert_conversation(conversation_id, title)
        db.save_message(conversation_id, "user", question)
        history = db.get_history(conversation_id)

        # Cached flagship replay (SPEC §3.9): instant, low-latency scripted path. Live fallback
        # if no cache. Only replay for a fresh conversation turn (no prior context to honour).
        use_cache = os.environ.get("RAMSAY_DISABLE_CACHE") != "1" and len(history) <= 1
        cached = cache.get_cached(question) if use_cache else None
        if cached:
            final_answer = ""
            for ev in cached:
                if ev.get("stage") in ("meta",):
                    continue
                if ev.get("stage") == "final":
                    final_answer = ev.get("answer") or ""
                if ev.get("stage") == "done":
                    continue
                yield sse(ev)
                await asyncio.sleep(0.35)  # gentle pacing so the trace still "thinks" on screen
            db.save_message(conversation_id, "assistant", final_answer)
            yield sse({"stage": "done", "conversationId": conversation_id,
                       "demoMode": db.is_demo(), "cached": True})
            db.save_trace(conversation_id, turn_id, cached)
            return

        async def worker():
            try:
                res = await run_supervisor(question, history, emit)
                db.save_message(conversation_id, "assistant", res.get("finalAnswer") or "")
                emit({"stage": "done", "conversationId": conversation_id, "demoMode": db.is_demo()})
            except Exception as e:
                emit({"stage": "error", "message": str(e)})
                emit({"stage": "done", "conversationId": conversation_id, "demoMode": db.is_demo()})

        task = asyncio.create_task(worker())

        while True:
            event = await queue.get()
            yield sse(event)
            if event.get("stage") == "done":
                break
        await task
        # Persist the full trace for replay.
        db.save_trace(conversation_id, turn_id, events)
        # Cache a clean flagship run so subsequent demos of the scripted questions are instant.
        if use_cache:
            cache.save_cache(question, events)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ---- Static frontend ----
DIST = Path(__file__).parent / "frontend" / "dist"
if (DIST / "assets").exists():
    app.mount("/assets", StaticFiles(directory=DIST / "assets"), name="assets")


@app.get("/{full_path:path}")
def spa(full_path: str):
    if full_path.startswith("api/"):
        return JSONResponse({"error": "Not found"}, status_code=404)
    index = DIST / "index.html"
    if index.exists():
        return FileResponse(index)
    return JSONResponse({"error": "frontend not built"}, status_code=503)
