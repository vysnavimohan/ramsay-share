// Genie Conversation API client — poll-based wrapper.
import { getToken } from './auth.js';

const HOST = process.env.DATABRICKS_HOST_URL || 'https://adb-7405610211988135.15.azuredatabricks.net';

async function api(method, path, body) {
  const tok = await getToken(HOST);
  const r = await fetch(HOST + path, {
    method,
    headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json' },
    body: body != null ? JSON.stringify(body) : undefined,
  });
  const text = await r.text();
  if (!r.ok) throw new Error(`Genie ${method} ${path} -> ${r.status}: ${text.slice(0, 500)}`);
  return text ? JSON.parse(text) : {};
}

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

/**
 * Ask a Genie space one question, poll to completion, return a structured result.
 * @returns {Promise<{answer, sql, description, thoughts, columns, rows, rowCount, statementId, error}>}
 */
export async function askGenie(spaceId, question, { timeoutMs = 300000, pollMs = 2000 } = {}) {
  const start = Date.now();
  const startResp = await api('POST', `/api/2.0/genie/spaces/${spaceId}/start-conversation`, {
    content: question,
  });
  const conversationId = startResp.conversation_id;
  const messageId = startResp.message_id || startResp.message?.id;

  let msg;
  while (Date.now() - start < timeoutMs) {
    msg = await api(
      'GET',
      `/api/2.0/genie/spaces/${spaceId}/conversations/${conversationId}/messages/${messageId}`,
    );
    const st = msg.status;
    if (['COMPLETED', 'FAILED', 'CANCELLED', 'QUERY_RESULT_EXPIRED'].includes(st)) break;
    await sleep(pollMs);
  }

  const latencyMs = Date.now() - start;

  if (!msg || msg.status !== 'COMPLETED') {
    return {
      error: msg?.error?.error || `Genie status ${msg?.status || 'TIMEOUT'}`,
      answer: null, sql: null, columns: [], rows: [], rowCount: 0, latencyMs,
      conversationId, messageId,
    };
  }

  const attachments = msg.attachments || [];
  const queryAtt = attachments.find((a) => a.query);
  const textAtt = attachments.find((a) => a.text);

  let sql = null, description = null, thoughts = [], statementId = null, rowCount = 0;
  if (queryAtt) {
    sql = queryAtt.query.query;
    description = queryAtt.query.description;
    thoughts = (queryAtt.query.thoughts || []).map((t) => t.content);
    statementId = queryAtt.query.statement_id;
    rowCount = queryAtt.query.query_result_metadata?.row_count ?? 0;
  }

  const answer = textAtt?.text?.content || null;

  // Fetch actual rows if there is a query attachment.
  let columns = [], rows = [];
  if (queryAtt) {
    try {
      const qr = await api(
        'GET',
        `/api/2.0/genie/spaces/${spaceId}/conversations/${conversationId}/messages/${messageId}/attachments/${queryAtt.attachment_id}/query-result`,
      );
      const sr = qr.statement_response || {};
      columns = (sr.manifest?.schema?.columns || []).map((c) => c.name);
      rows = sr.result?.data_array || [];
      rowCount = sr.manifest?.total_row_count ?? rowCount;
    } catch (e) {
      // Non-fatal; keep answer + sql.
    }
  }

  return {
    error: null, answer, sql, description, thoughts,
    columns, rows, rowCount, statementId, latencyMs,
    conversationId, messageId,
  };
}
