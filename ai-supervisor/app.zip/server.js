// Zero-dependency HTTP server (Node built-ins only) so the Databricks App
// needs no npm install step.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { runSupervisor, SPACES } from './supervisor.js';
import { initDb, isDemoMode, saveMessage, saveTrace, getHistory } from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 8000;
const PUBLIC = path.join(__dirname, 'public');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};

function serveStatic(res, urlPath) {
  let rel = urlPath === '/' ? '/index.html' : urlPath;
  const filePath = path.join(PUBLIC, path.normalize(rel).replace(/^(\.\.[/\\])+/, ''));
  if (!filePath.startsWith(PUBLIC)) {
    res.writeHead(403).end();
    return;
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' }).end('Not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(filePath)] || 'application/octet-stream' });
    res.end(data);
  });
}

async function handleStream(req, res, url) {
  const question = (url.searchParams.get('q') || '').trim();
  const conversationId = url.searchParams.get('c') || randomUUID();
  if (!question) {
    res.writeHead(400, { 'Content-Type': 'application/json' }).end(JSON.stringify({ error: 'Missing question' }));
    return;
  }
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
  });

  const send = (event) => res.write(`data: ${JSON.stringify(event)}\n\n`);
  const emit = (event) => {
    send(event);
    saveTrace(conversationId, event.stage, event).catch(() => {});
  };

  try {
    send({ stage: 'meta', conversationId });
    await saveMessage(conversationId, 'user', question);
    const history = await getHistory(conversationId);
    const { finalAnswer } = await runSupervisor({ question, history, emit });
    await saveMessage(conversationId, 'assistant', finalAnswer || '');
    send({ stage: 'done', conversationId, demoMode: isDemoMode() });
  } catch (e) {
    console.error('[chat] error:', e);
    send({ stage: 'error', message: e instanceof Error ? e.message : String(e) });
  } finally {
    res.end();
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const p = url.pathname;

  if (p === '/api/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', demoMode: isDemoMode(), spaces: Object.keys(SPACES) }));
    return;
  }
  if (p === '/api/spaces') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(Object.fromEntries(Object.entries(SPACES).map(([k, v]) => [k, { label: v.label, desc: v.desc }]))));
    return;
  }
  if (p === '/api/chat/stream') {
    await handleStream(req, res, url);
    return;
  }
  if (p.startsWith('/api/history/')) {
    try {
      const rows = await getHistory(decodeURIComponent(p.slice('/api/history/'.length)));
      res.writeHead(200, { 'Content-Type': 'application/json' }).end(JSON.stringify(rows));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' }).end(JSON.stringify({ error: e.message }));
    }
    return;
  }
  if (p.startsWith('/api/')) {
    res.writeHead(404, { 'Content-Type': 'application/json' }).end(JSON.stringify({ error: 'Not found' }));
    return;
  }
  serveStatic(res, p);
});

initDb().then((r) => {
  server.listen(PORT, () => {
    console.log(`Ramsay AI Supervisor (zero-dep) on :${PORT} (demoMode=${r.demoMode})`);
  });
});
