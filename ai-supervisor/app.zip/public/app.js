const main = document.getElementById('main');
const input = document.getElementById('q');
const sendBtn = document.getElementById('send');
const statusText = document.getElementById('statusText');
const emptyEl = document.getElementById('empty');
let conversationId = null;
let busy = false;

const SUGGESTIONS = [
  'Compare capacity utilization and wait times between Ashtead Hospital and Springfield Hospital',
  'What is the RTT breach percentage by site?',
  'Show staffing fill rate and theatre utilisation by site',
  'Which services have the longest waiting times and how does revenue break down by payor?',
];

const suggest = document.getElementById('suggest');
SUGGESTIONS.forEach((s) => {
  const b = document.createElement('button');
  b.textContent = s;
  b.onclick = () => { if (!busy) { input.value = s; ask(); } };
  suggest.appendChild(b);
});

function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html != null) e.innerHTML = html;
  return e;
}
function esc(s) {
  return (s == null ? '' : String(s)).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
}

function renderTable(columns, rows) {
  if (!columns || !columns.length) return '';
  const head = '<tr>' + columns.map((c) => `<th>${esc(c)}</th>`).join('') + '</tr>';
  const body = rows.slice(0, 10).map((r) => '<tr>' + r.map((v) => `<td>${esc(v)}</td>`).join('') + '</tr>').join('');
  return `<table>${head}${body}</table>`;
}

function ask() {
  const question = input.value.trim();
  if (!question || busy) return;
  busy = true;
  sendBtn.disabled = true;
  emptyEl?.remove();
  statusText.textContent = 'Thinking…';

  const turn = el('div', 'turn');
  turn.appendChild(el('div', 'userq', `<span class="tag">Question</span>${esc(question)}`));

  const trace = el('div', 'trace');
  const thead = el('div', 'trace-head', '<span>◆ Reasoning trace</span>');
  const tbody = el('div', 'trace-body');
  thead.onclick = () => trace.classList.toggle('collapsed');
  trace.appendChild(thead);
  trace.appendChild(tbody);
  turn.appendChild(trace);
  main.appendChild(turn);
  main.scrollTop = main.scrollHeight;

  input.value = '';
  const cardMap = {};
  let stageNum = 0;
  const addStage = (title) => {
    stageNum++;
    const s = el('div', 'stage');
    s.appendChild(el('div', 'stage-title', `<span class="n">${stageNum}</span>${title}`));
    tbody.appendChild(s);
    return s;
  };

  const params = new URLSearchParams({ q: question });
  if (conversationId) params.set('c', conversationId);
  const es = new EventSource('/api/chat/stream?' + params.toString());

  let routeStage = null, agentsStage = null, finalEl = null;

  es.onmessage = (ev) => {
    const e = JSON.parse(ev.data);
    switch (e.stage) {
      case 'meta':
        conversationId = e.conversationId;
        break;
      case 'decompose_start':
        addStage('Decompose');
        break;
      case 'decompose': {
        const st = tbody.lastChild;
        e.subquestions.forEach((q) => st.appendChild(el('div', 'sub', esc(q))));
        break;
      }
      case 'route': {
        routeStage = addStage('Route');
        e.routes.forEach((r) => {
          const d = el('div', 'route');
          d.innerHTML = `<span class="chip ${r.agent}">${esc(r.agentLabel)}</span>${esc(r.question)}` +
            (r.rationale ? `<div class="rat">${esc(r.rationale)}</div>` : '');
          routeStage.appendChild(d);
        });
        break;
      }
      case 'agents_start':
        agentsStage = addStage('Agent calls (parallel)');
        break;
      case 'agent_call_start': {
        const card = el('div', 'card');
        card.innerHTML =
          `<div class="card-head"><span class="chip ${e.agent}">${esc(e.agentLabel)}</span>` +
          `<span class="q">${esc(e.question)}</span><span class="spin"></span></div>` +
          `<div class="card-body"><div class="lbl">Running…</div></div>`;
        agentsStage.appendChild(card);
        cardMap[e.agent + '|' + e.question] = card;
        break;
      }
      case 'agent_call_done': {
        const key = e.agent + '|' + e.question;
        const card = cardMap[key] || el('div', 'card');
        if (!cardMap[key]) agentsStage.appendChild(card);
        let body = '';
        if (e.error) {
          body = `<div class="err">Error: ${esc(e.error)}</div>`;
        } else {
          if (e.sql) body += `<div class="lbl">Generated SQL</div><pre class="sql">${esc(e.sql)}</pre>`;
          body += `<div class="lbl">Result — ${e.rowCount} row(s)</div>${renderTable(e.columns, e.rows)}`;
          if (e.answer) body += `<div class="lbl">Agent answer</div><div style="font-size:13px">${esc(e.answer)}</div>`;
        }
        card.innerHTML =
          `<div class="card-head"><span class="chip ${e.agent}">${esc(e.agentLabel)}</span>` +
          `<span class="q">${esc(e.question)}</span><span class="lat">${(e.latencyMs/1000).toFixed(1)}s</span></div>` +
          `<div class="card-body">${body}</div>`;
        main.scrollTop = main.scrollHeight;
        break;
      }
      case 'synthesize_start':
        addStage('Synthesize');
        break;
      case 'synthesize': {
        const st = tbody.lastChild;
        st.appendChild(el('div', 'sub', 'Sources: ' + e.sources.map(esc).join(', ')));
        break;
      }
      case 'final': {
        finalEl = el('div', 'final', `<div class="lbl2">Answer</div><div class="body">${esc(e.answer)}</div>`);
        turn.appendChild(finalEl);
        main.scrollTop = main.scrollHeight;
        break;
      }
      case 'done':
        statusText.textContent = e.demoMode ? 'Ready (memory: in-app)' : 'Ready (memory: Lakebase)';
        es.close();
        busy = false; sendBtn.disabled = false;
        break;
      case 'error':
        tbody.appendChild(el('div', 'err', 'Error: ' + esc(e.message)));
        statusText.textContent = 'Error';
        es.close();
        busy = false; sendBtn.disabled = false;
        break;
    }
  };
  es.onerror = () => {
    if (busy) { statusText.textContent = 'Connection lost'; es.close(); busy = false; sendBtn.disabled = false; }
  };
}

sendBtn.onclick = ask;
input.addEventListener('keydown', (e) => { if (e.key === 'Enter') ask(); });
