// Persistence with ZERO npm dependencies.
// Primary: Databricks SQL warehouse -> Delta tables in ramsay_health.ops
//   (conversation + trace memory, durable, queryable in UC).
// This avoids shipping a Postgres driver so the app has no npm install step.
// Lakebase (ramsay-supervisor-lb) remains the intended production OLTP backend;
// see STATE.md. If the warehouse is unreachable, falls back to in-memory demo mode.
import { getToken } from './auth.js';

const HOST = process.env.DATABRICKS_HOST_URL || 'https://adb-7405610211988135.15.azuredatabricks.net';
const WAREHOUSE = process.env.DATABRICKS_WAREHOUSE_ID || '886fd3b1e294db8c';
const CATALOG = process.env.MEMORY_CATALOG || 'ramsay_health';
const SCHEMA = process.env.MEMORY_SCHEMA || 'ops';
const T_MSG = `${CATALOG}.${SCHEMA}.app_messages`;
const T_TRACE = `${CATALOG}.${SCHEMA}.app_traces`;

let demoMode = false;
const memory = { messages: [], traces: [] };

async function sqlExec(statement, params) {
  const tok = await getToken(HOST);
  const body = {
    warehouse_id: WAREHOUSE,
    statement,
    wait_timeout: '30s',
    format: 'JSON_ARRAY',
    disposition: 'INLINE',
  };
  if (params) body.parameters = params;
  let r = await fetch(`${HOST}/api/2.0/sql/statements`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`SQL ${r.status}: ${(await r.text()).slice(0, 300)}`);
  let d = await r.json();
  let state = d.status?.state;
  const id = d.statement_id;
  while (state === 'PENDING' || state === 'RUNNING') {
    await new Promise((res) => setTimeout(res, 1000));
    r = await fetch(`${HOST}/api/2.0/sql/statements/${id}`, {
      headers: { Authorization: `Bearer ${tok}` },
    });
    d = await r.json();
    state = d.status?.state;
  }
  if (state !== 'SUCCEEDED') {
    throw new Error(`SQL failed: ${JSON.stringify(d.status?.error || {}).slice(0, 300)}`);
  }
  const cols = (d.manifest?.schema?.columns || []).map((c) => c.name);
  const rows = d.result?.data_array || [];
  return rows.map((row) => Object.fromEntries(cols.map((c, i) => [c, row[i]])));
}

export async function initDb() {
  try {
    await sqlExec(
      `CREATE TABLE IF NOT EXISTS ${T_MSG} (
         conversation_id STRING, role STRING, content STRING, created_at TIMESTAMP
       )`,
    );
    await sqlExec(
      `CREATE TABLE IF NOT EXISTS ${T_TRACE} (
         conversation_id STRING, stage STRING, data STRING, created_at TIMESTAMP
       )`,
    );
    console.log(`[db] Memory tables ready: ${T_MSG}, ${T_TRACE}`);
    return { demoMode: false };
  } catch (e) {
    console.warn('[db] init failed, demo (in-memory) mode:', e.message);
    demoMode = true;
    return { demoMode: true, error: e.message };
  }
}

export function isDemoMode() {
  return demoMode;
}

export async function ensureConversation() {
  /* no-op: messages table is keyed by conversation_id */
}

function esc(s) {
  return String(s == null ? '' : s).replace(/'/g, "''");
}

export async function saveMessage(conversationId, role, content) {
  if (demoMode) {
    memory.messages.push({ conversation_id: conversationId, role, content, created_at: new Date() });
    return;
  }
  try {
    await sqlExec(
      `INSERT INTO ${T_MSG} VALUES ('${esc(conversationId)}','${esc(role)}','${esc(content)}', current_timestamp())`,
    );
  } catch (e) {
    console.warn('[db] saveMessage failed:', e.message);
  }
}

export async function saveTrace(conversationId, stage, data) {
  if (demoMode) {
    memory.traces.push({ conversation_id: conversationId, stage, data, created_at: new Date() });
    return;
  }
  try {
    await sqlExec(
      `INSERT INTO ${T_TRACE} VALUES ('${esc(conversationId)}','${esc(stage)}','${esc(JSON.stringify(data))}', current_timestamp())`,
    );
  } catch (e) {
    /* trace persistence is best-effort */
  }
}

export async function getHistory(conversationId) {
  if (demoMode) {
    return memory.messages.filter((m) => m.conversation_id === conversationId);
  }
  try {
    return await sqlExec(
      `SELECT role, content, created_at FROM ${T_MSG} WHERE conversation_id = '${esc(conversationId)}' ORDER BY created_at`,
    );
  } catch (e) {
    return [];
  }
}
