"""Genie Conversation API client — poll-based wrapper (async).

Ports genie.js: start-conversation -> poll message -> extract SQL + rows.
"""
import json
import time
import asyncio
import urllib.request
import urllib.error

from .config import HOST, get_token


def _api(method: str, path: str, body: dict | None = None) -> dict:
    req = urllib.request.Request(
        HOST + path,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Authorization": "Bearer " + get_token(), "Content-Type": "application/json"},
        method=method,
    )
    try:
        raw = urllib.request.urlopen(req).read()
        return json.loads(raw or b"{}")
    except urllib.error.HTTPError as e:
        detail = e.read().decode()[:500]
        raise RuntimeError(f"Genie {method} {path} -> {e.code}: {detail}")


def _ask_genie_sync(space_id: str, question: str, timeout_ms=300000, poll_ms=2000) -> dict:
    start = time.time()
    startr = _api("POST", f"/api/2.0/genie/spaces/{space_id}/start-conversation", {"content": question})
    conversation_id = startr.get("conversation_id")
    message_id = startr.get("message_id") or (startr.get("message") or {}).get("id")

    msg = None
    while (time.time() - start) * 1000 < timeout_ms:
        msg = _api("GET", f"/api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages/{message_id}")
        if msg.get("status") in ("COMPLETED", "FAILED", "CANCELLED", "QUERY_RESULT_EXPIRED"):
            break
        time.sleep(poll_ms / 1000)

    latency_ms = int((time.time() - start) * 1000)

    if not msg or msg.get("status") != "COMPLETED":
        err = (msg or {}).get("error") or {}
        return {
            "error": err.get("error") or f"Genie status {(msg or {}).get('status', 'TIMEOUT')}",
            "answer": None, "sql": None, "description": None, "thoughts": [],
            "columns": [], "rows": [], "rowCount": 0, "latencyMs": latency_ms,
            "conversationId": conversation_id, "messageId": message_id,
        }

    attachments = msg.get("attachments") or []
    query_att = next((a for a in attachments if a.get("query")), None)
    text_att = next((a for a in attachments if a.get("text")), None)

    sql = description = None
    thoughts, statement_id, row_count = [], None, 0
    if query_att:
        q = query_att["query"]
        sql = q.get("query")
        description = q.get("description")
        thoughts = [t.get("content") for t in (q.get("thoughts") or [])]
        statement_id = q.get("statement_id")
        row_count = (q.get("query_result_metadata") or {}).get("row_count", 0)

    answer = (text_att or {}).get("text", {}).get("content") if text_att else None

    columns, rows = [], []
    if query_att:
        try:
            qr = _api(
                "GET",
                f"/api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages/{message_id}"
                f"/attachments/{query_att['attachment_id']}/query-result",
            )
            sr = qr.get("statement_response") or {}
            columns = [c["name"] for c in (sr.get("manifest", {}).get("schema", {}).get("columns") or [])]
            rows = sr.get("result", {}).get("data_array") or []
            row_count = sr.get("manifest", {}).get("total_row_count", row_count)
        except Exception:
            pass

    return {
        "error": None, "answer": answer, "sql": sql, "description": description,
        "thoughts": thoughts, "columns": columns, "rows": rows, "rowCount": row_count,
        "statementId": statement_id, "latencyMs": latency_ms,
        "conversationId": conversation_id, "messageId": message_id,
    }


async def ask_genie(space_id: str, question: str) -> dict:
    return await asyncio.to_thread(_ask_genie_sync, space_id, question)
