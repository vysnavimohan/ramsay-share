"""Deterministic analytics for the Shift-Activity and Forecast tabs.

Reads Genie-source views in ramsay_health.ops via the SQL Statement Execution API
using the same app/dev token. All numbers computed server-side so the tabs are
fast + reproducible (the AI narrative is a separate path via the supervisor).
"""
import json
import urllib.request
import urllib.error

from .config import HOST, WAREHOUSE_ID, get_token

CS = "ramsay_health.ops"

# Per-PROCEDURE-GROUP theatre minutes (SPEC §3.2) — mirrors build_health/config.PROC_MINUTES
# aggregated to the ProcedureGroup grain that vw_case_ledger / vw_finance_base expose.
# A hip (120) consumes ~5x the slack of a cataract (25) — this is what makes the
# utilisation-headroom signal real. Single source of truth for the app tier.
PROC_GROUP_MINUTES = {
    "Orthopaedic - Hip": 120.0,
    "Orthopaedic - Knee": 95.0,     # blend of TKR (110) + arthroscopy (45)
    "Urological": 90.0,
    "General Surgery": 60.0,
    "ENT": 40.0,
    "Endoscopy": 35.0,
    "Gynaecology": 30.0,
    "Diagnostic Imaging": 30.0,
    "Ophthalmic": 25.0,
}
DEFAULT_PROC_MINUTES = 75.0
SESSIONS_PER_DAY = 2  # AM + PM

# Utilisation-headroom bands (SPEC §3.3): green < AMBER_AT, amber < RED_AT, red >= RED_AT.
AMBER_AT = 90.0
RED_AT = 100.0
# Simple wait elasticity: a 10-point rise in theatre utilisation lengthens waits ~8%.
WAIT_ELASTICITY = 0.8

SITES = {
    "Rivers Hospital": "0304", "Ashtead Hospital": "0333", "Springfield Hospital": "0312",
    "Oaklands Hospital": "0327", "Pinehill Hospital": "0341",
}
PROC_GROUPS = [
    "Orthopaedic - Hip", "Orthopaedic - Knee", "Urological", "General Surgery",
    "Ophthalmic", "Endoscopy", "ENT", "Gynaecology", "Diagnostic Imaging",
]


def proc_minutes(group: str) -> float:
    return PROC_GROUP_MINUTES.get(group, DEFAULT_PROC_MINUTES)


def util_band(util: float) -> str:
    if util >= RED_AT:
        return "red"
    if util >= AMBER_AT:
        return "amber"
    return "green"


def _sql(stmt: str) -> list[dict]:
    body = json.dumps({
        "warehouse_id": WAREHOUSE_ID, "statement": stmt, "wait_timeout": "50s",
        "format": "JSON_ARRAY", "disposition": "INLINE",
    }).encode()
    req = urllib.request.Request(
        f"{HOST}/api/2.0/sql/statements", data=body,
        headers={"Authorization": "Bearer " + get_token(), "Content-Type": "application/json"},
        method="POST",
    )
    import time
    try:
        d = json.loads(urllib.request.urlopen(req).read())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"SQL {e.code}: {e.read().decode()[:300]}")
    sid = d.get("statement_id")
    while d.get("status", {}).get("state") in ("PENDING", "RUNNING"):
        time.sleep(1.5)
        g = urllib.request.Request(
            f"{HOST}/api/2.0/sql/statements/{sid}",
            headers={"Authorization": "Bearer " + get_token()})
        d = json.loads(urllib.request.urlopen(g).read())
    if d.get("status", {}).get("state") != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(d.get("status", {}).get("error", {}))[:300])
    cols = [c["name"] for c in d.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, r)) for r in (d.get("result", {}).get("data_array") or [])]


def _f(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def options():
    return {"sites": list(SITES.keys()), "procedureGroups": PROC_GROUPS}


# ---------- TAB A: shift activity ----------
def _finance_scope(sites, procs, date_from=None, date_to=None):
    site_list = ",".join("'" + s.replace("'", "''") + "'" for s in sites)
    proc_list = ",".join("'" + p.replace("'", "''") + "'" for p in procs)
    where = [f"SiteName IN ({site_list})", f"ProcedureGroup IN ({proc_list})"]
    if date_from and date_to:
        where.append(f"InvoiceDate BETWEEN DATE'{date_from}' AND DATE'{date_to}'")
    stmt = f"""SELECT SiteName, ProcedureGroup, COUNT(*) AS cases, SUM(Revenue) AS revenue
               FROM {CS}.vw_finance_base
               WHERE {' AND '.join(where)}
               GROUP BY SiteName, ProcedureGroup"""
    return _sql(stmt)


def _site_baseline():
    """Baseline theatre stats per site: utilisation, daily planned/spare minutes, avg wait.

    Uses PAST session-days only (SessionDate < current_date) so the derived planned/used
    minutes reflect the ledger-seeded actuals (future days are projections).
    """
    rows = _sql(f"""SELECT SiteName,
        COUNT(DISTINCT SessionDate) AS days,
        SUM(CAST(UsedMinutes AS DOUBLE)) AS used_min,
        SUM(CAST(PlannedMinutes AS DOUBLE)) AS planned_min
        FROM {CS}.vw_theatre_throughput
        WHERE SessionDate < current_date()
        GROUP BY SiteName""")
    waits = _sql(f"""SELECT SiteName, AVG(CAST(WeeksWaiting AS DOUBLE)) AS avg_wait
        FROM {CS}.vw_waiting_list GROUP BY SiteName""")
    wait_map = {w["SiteName"]: _f(w["avg_wait"]) for w in waits}
    out = {}
    for r in rows:
        days = int(_f(r["days"])) or 1
        used = _f(r["used_min"]); planned = _f(r["planned_min"])
        util = (used / planned * 100.0) if planned else 0.0
        out[r["SiteName"]] = {
            "avg_util": util,
            "planned_per_day": planned / days,       # total planned theatre minutes / day
            "used_per_day": used / days,
            "spare_per_day": (planned - used) / days,  # daily spare theatre minutes
            "days": days,
            "avg_wait": wait_map.get(r["SiteName"], 0.0),
        }
    return out


def _ledger_daily_rate(sources, procs):
    """Avg daily surgical cases + revenue per (source site, procedure group) from vw_case_ledger.

    Uses PAST days (CaseDate < current_date) — the invoiced ledger — so this is the true
    daily throughput, not a lifetime÷window fudge.
    """
    site_list = ",".join("'" + s.replace("'", "''") + "'" for s in sources)
    proc_list = ",".join("'" + p.replace("'", "''") + "'" for p in procs)
    rows = _sql(f"""SELECT SiteName, ProcedureGroup,
        SUM(Cases) AS cases, SUM(Revenue) AS revenue,
        COUNT(DISTINCT CaseDate) AS days
        FROM {CS}.vw_case_ledger
        WHERE SiteName IN ({site_list}) AND ProcedureGroup IN ({proc_list})
          AND CaseDate < current_date()
        GROUP BY SiteName, ProcedureGroup""")
    out = {}
    for r in rows:
        days = int(_f(r["days"])) or 1
        out[(r["SiteName"], r["ProcedureGroup"])] = {
            "daily_cases": _f(r["cases"]) / days,
            "daily_rev": _f(r["revenue"]) / days,
        }
    return out


def compute_shift(sources, targets, procs, pct, date_from=None, date_to=None, use_average=True, horizon_days=30):
    """Deterministic what-if (SPEC §3.2/§3.3/§6.6).

    - Cases moved  = ledger DAILY rate x horizon_days x pct   (per source site x procedure).
    - Minutes moved = Σ cases_moved x PROC_GROUP_MINUTES[proc] (per-procedure, NOT flat 90).
    - Target util  = utilisation HEADROOM BAND rising from baseline (green/amber/red), the
      allocation capped at each target's real spare minutes (guardrail), with re-spill.
    - Both sites' waits recompute: source eases, targets tick up (WAIT_ELASTICITY).
    """
    frac = max(0.0, min(100.0, _f(pct))) / 100.0
    base = _site_baseline()

    if use_average:
        window_days = horizon_days
        rate = _ledger_daily_rate(sources, procs)
    else:
        window_days = None  # date-range actuals path
        fin = _finance_scope(list(set(sources)), procs, date_from, date_to)

    # ---- source movement, per (site, procedure) ----
    per_proc = {}          # proc -> {cases, rev, minutes}
    per_source_min = {}    # source site -> minutes removed
    src_moved_cases = 0.0
    src_moved_rev = 0.0
    minutes_moved = 0.0
    for s in sources:
        for p in procs:
            if use_average:
                r = rate.get((s, p))
                if not r:
                    continue
                mc = r["daily_cases"] * window_days * frac
                mv = r["daily_rev"] * window_days * frac
            else:
                row = next((x for x in fin if x["SiteName"] == s and x["ProcedureGroup"] == p), None)
                if not row:
                    continue
                mc = int(_f(row["cases"])) * frac
                mv = _f(row["revenue"]) * frac
            mins = mc * proc_minutes(p)
            src_moved_cases += mc
            src_moved_rev += mv
            minutes_moved += mins
            per_proc.setdefault(p, {"cases": 0.0, "rev": 0.0, "minutes": 0.0})
            per_proc[p]["cases"] += mc; per_proc[p]["rev"] += mv; per_proc[p]["minutes"] += mins
            per_source_min[s] = per_source_min.get(s, 0.0) + mins

    period = window_days if use_average else _target_window_days(date_from, date_to, base)

    # ---- target available slack (minutes) over the same window ----
    tgt_slack = {}
    for t in targets:
        b = base.get(t, {})
        tgt_slack[t] = max(0.0, b.get("spare_per_day", 0.0) * period)

    # ---- GUARDRAIL allocation: distribute minutes to targets, capped at slack, re-spill ----
    alloc_min, clamp_events, residual = _allocate_with_guardrail(minutes_moved, targets, tgt_slack)

    per_site = []
    # source sites: utilisation & wait ease
    for s in sources:
        b = base.get(s, {})
        util = b.get("avg_util", 0.0)
        planned = b.get("planned_per_day", 0.0) * period
        removed = per_source_min.get(s, 0.0)
        util_after = max(0.0, util - (removed / planned * 100.0)) if planned else util
        wait = b.get("avg_wait", 0.0)
        wait_after = round(wait * (1 + WAIT_ELASTICITY * (util_after - util) / 100.0), 1)
        per_site.append({
            "site": s, "role": "source",
            "utilBefore": round(util, 1), "utilAfter": round(util_after, 1),
            "bandBefore": util_band(util), "bandAfter": util_band(util_after),
            "waitBefore": round(wait, 1), "waitAfter": wait_after,
            "minutesMoved": round(removed, 0),
        })

    # target sites: utilisation & wait rise (capped at slack by guardrail)
    for t in targets:
        b = base.get(t, {})
        util = b.get("avg_util", 0.0)
        planned = b.get("planned_per_day", 0.0) * period
        min_in = alloc_min.get(t, 0.0)
        util_after = util + (min_in / planned * 100.0) if planned else util
        wait = b.get("avg_wait", 0.0)
        wait_after = round(wait * (1 + WAIT_ELASTICITY * (util_after - util) / 100.0), 1)
        per_site.append({
            "site": t, "role": "target",
            "utilBefore": round(util, 1), "utilAfter": round(util_after, 1),
            "bandBefore": util_band(util), "bandAfter": util_band(util_after),
            "waitBefore": round(wait, 1), "waitAfter": wait_after,
            "slackMinutes": round(tgt_slack[t], 0), "minutesIn": round(min_in, 0),
        })

    chart = [{"site": p["site"], "Before": p["utilBefore"], "After": p["utilAfter"]} for p in per_site]

    # feasibility now = is anything not absorbable (residual > 0 after re-spill) OR any target red
    any_red = any(p["role"] == "target" and p["bandAfter"] == "red" for p in per_site)
    feasible = residual <= 1.0 and not any_red
    over_sites = [p["site"] for p in per_site if p["role"] == "target" and p["bandAfter"] in ("red",)]

    return {
        "kpis": {
            "casesShifted": round(src_moved_cases, 0),
            "revenueShifted": round(src_moved_rev, 0),
            "minutesMoved": round(minutes_moved, 0),
            "feasible": feasible,
            "infeasibleSites": over_sites,
            "residualMinutes": round(residual, 0),
        },
        "perSite": per_site,
        "chart": chart,
        "clampEvents": clamp_events,
        "perProcedure": [{"procedure": k, "casesMoved": round(v["cases"], 0),
                          "revenueMoved": round(v["rev"], 0), "minutesMoved": round(v["minutes"], 0),
                          "minutesPerCase": proc_minutes(k)}
                         for k, v in per_proc.items()],
        "assumptions": {
            "minutesPerCase": "per-procedure (see perProcedure)", "sessionsPerDay": SESSIONS_PER_DAY,
            "capacityBasis": f"{horizon_days}-day average" if use_average else "date-range actuals",
            "horizonDays": horizon_days if use_average else None,
            "amberAt": AMBER_AT, "redAt": RED_AT, "pct": pct,
        },
    }


def _target_window_days(date_from, date_to, base):
    if date_from and date_to:
        from datetime import date
        try:
            a = date.fromisoformat(date_from); b = date.fromisoformat(date_to)
            return max(1, (b - a).days + 1)
        except ValueError:
            pass
    return 30


def _allocate_with_guardrail(total_minutes, targets, slack):
    """Distribute total_minutes across targets proportional to slack, each CAPPED at its slack;
    re-spill overflow to targets with remaining headroom. Returns (alloc, events, residual)."""
    alloc = {t: 0.0 for t in targets}
    events = []
    remaining = {t: slack.get(t, 0.0) for t in targets}
    to_place = total_minutes
    # iterate: each round, split to_place by remaining-slack proportion, cap, repeat with overflow
    for _ in range(len(targets) + 2):
        if to_place <= 1.0:
            break
        avail = {t: remaining[t] for t in targets if remaining[t] > 1.0}
        cap_total = sum(avail.values())
        if cap_total <= 1.0:
            break
        overflow = 0.0
        for t, cap in avail.items():
            want = to_place * (cap / cap_total)
            give = min(want, remaining[t])
            if want > remaining[t] + 0.5:
                events.append({"site": t, "clampedMinutes": round(want - give, 0),
                               "note": f"{t} capped at slack {round(remaining[t],0)} min; overflow re-spilled"})
            alloc[t] += give
            remaining[t] -= give
            overflow += (want - give)
        to_place = overflow
    residual = max(0.0, to_place)
    return alloc, events, residual


def shift_narrative(sources, targets, procs, pct):
    src = " and ".join(sources) or "the selected source sites"
    tgt = " and ".join(targets) or "the selected target sites"
    plist = ", ".join(procs) or "the selected procedures"
    return (f"Shift {pct}% of {plist} activity from {src} to {tgt} — what is the impact on "
            f"capacity utilisation, workforce cost, and margin, and is there enough theatre "
            f"capacity at the target sites to absorb it?")


# ---------- TAB B: forecast ----------
def forecast(sites=None):
    site_filter = ""
    if sites:
        sl = ",".join("'" + s.replace("'", "''") + "'" for s in sites)
        site_filter = f"WHERE SiteName IN ({sl})"

    util = _sql(f"""SELECT SiteName, CAST(ForecastDate AS DATE) AS d,
        CAST(UtilForecast AS DOUBLE) f, CAST(UtilLower AS DOUBLE) lo, CAST(UtilUpper AS DOUBLE) hi
        FROM {CS}.vw_forecast_theatre_util {site_filter} ORDER BY SiteName, d""")
    wait = _sql(f"""SELECT SiteName, CAST(ForecastDate AS DATE) AS d,
        CAST(WaitWeeksForecast AS DOUBLE) f, CAST(WaitLower AS DOUBLE) lo, CAST(WaitUpper AS DOUBLE) hi
        FROM {CS}.vw_forecast_wait {site_filter} ORDER BY SiteName, d""")

    # recent util actuals (last 45 days of session data) averaged per date
    hist = _sql(f"""SELECT SiteName, CAST(SessionDate AS DATE) AS d,
        AVG(CAST(UtilisationPct AS DOUBLE)) f
        FROM {CS}.vw_theatre_throughput {site_filter}
        GROUP BY SiteName, CAST(SessionDate AS DATE)
        ORDER BY d DESC LIMIT 400""")

    def reshape(rows, is_hist=False):
        out = {}
        for r in rows:
            out.setdefault(r["SiteName"], []).append({
                "date": str(r["d"]), "value": _f(r["f"]),
                **({} if is_hist else {"lower": _f(r["lo"]), "upper": _f(r["hi"])}),
            })
        return out

    return {
        "today": "2026-08-21",
        "util": reshape(util),
        "wait": reshape(wait),
        "utilHistory": reshape(hist, is_hist=True),
    }
