"""Supervisor state machine: decompose -> route -> parallel Genie -> synthesize.

Ports supervisor.js exactly (incl. the "ask by site, compare in synthesis" trick
and the "avoid parenthetical units" rule), and adds an LLM-decided CHART SPEC to
the synthesize step for inline recharts rendering.

GENIE-FIRST: all questions (including theatre-closure scenarios) are routed through
Genie agents for baseline data, then scenario arithmetic happens in synthesis.
"""
import asyncio
import re
import json

from .config import SPACES
from .llm import chat, parse_json
from .genie import ask_genie
from . import analytics

SPACE_KEYS = list(SPACES.keys())

# Sites in busiest->quietest order (SPEC §3.4) — used to seed the allocation guardrail's
# preference (quietest sites, with most slack, receive first).
SITE_ORDER = ["Rivers Hospital", "Oaklands Hospital", "Pinehill Hospital",
              "Ashtead Hospital", "Springfield Hospital"]


def _is_closure_scenario(q: str) -> bool:
    s = (q or "").lower()
    return ("close" in s or "closure" in s or "shut" in s) and ("theatre" in s or "theater" in s)


def _closure_guardrail(question: str):
    """Deterministic post-check (SPEC §3.5): compute each site's real 3-day theatre slack and,
    if we can infer impacted minutes, cap allocation per target slack with re-spill. Returns a
    fact block + structured events for the trace, or None if not applicable. Never fabricates —
    reads live slack from vw_theatre_throughput via analytics._site_baseline()."""
    try:
        base = analytics._site_baseline()
    except Exception:
        return None
    # source site = the one named in the question, if any
    src = next((s for s in SITE_ORDER if s.split()[0].lower() in question.lower()), None)
    # per-site 3-day spare theatre minutes (closure windows are typically a few days)
    window = 3
    slack = {s: round(base.get(s, {}).get("spare_per_day", 0.0) * window)
             for s in SITE_ORDER if s != src}
    total = sum(slack.values())
    facts = ["CAPACITY GUARDRAIL (deterministic, from live theatre data):",
             f"- Available 3-day theatre slack by receiving site (minutes): " +
             ", ".join(f"{s.split()[0]} {m}" for s, m in slack.items()),
             f"- Total receiving-network 3-day slack: {total} minutes.",
             "- Allocation MUST NOT push any receiving site's projected utilisation over 100%. "
             "Prefer quietest sites (most slack) first. If impacted minutes exceed total network "
             "slack, state the residual cannot be absorbed and recommend the earliest future date."]
    return {"source": src, "slack": slack, "total": total, "facts": "\n".join(facts)}


def _routing_catalog() -> str:
    return "\n".join(f"- {k} ({SPACES[k]['label']}): {SPACES[k]['desc']}" for k in SPACE_KEYS)


def _keyword_route(q: str) -> str:
    s = (q or "").lower()
    # cohort counts / demographic / pathway-status segmentation -> patient_finance (check FIRST)
    if re.search(r"how many patients|patients over|aged|age |cohort|admitted rtt|admitted pathway|"
                 r"revenue|payor|referral|finance|procedure group|channel|margin", s):
        return "patient_finance"
    if re.search(r"util|occupanc|bed |theatre capacity|diagnostic|slot|spare capacity|capacity", s):
        return "capacity"
    if re.search(r"staff|workforce|roster|fill rate|grade|shift|hours", s):
        return "workforce"
    if re.search(r"wait time|weeks waiting|rtt breach|breach percent|throughput|patient flow|cases completed", s):
        return "throughput_flow"
    return "patient_finance"


# ---- Deterministic decomposition for recognised flagship SCENARIOS ----
# LLM planners are non-deterministic on rich multi-part scenarios (they sometimes collapse a
# closure question to a single agent). For the two scenarios whose routing is contractually
# fixed (SPEC §7a Q1 closure, Q3 growth), we bypass the LLM planner and emit the exact,
# correctly-routed sub-question set. Improvised questions still use the LLM planner.
def _scenario_plan(question: str):
    ql = question.lower()
    if _is_closure_scenario(question):
        site = next((s for s in SITE_ORDER if s.split()[0].lower() in ql), "Springfield Hospital")
        return [
            {"agent": "capacity", "question": f"How many theatre cases are scheduled at {site} by specialty for the next 30 days?", "rationale": "cases impacted by closure"},
            {"agent": "capacity", "question": "What is the average theatre utilisation by site?", "rationale": "spare capacity at receiving sites"},
            {"agent": "throughput_flow", "question": "What is the average waiting time in weeks by site?", "rationale": "waiting-list impact"},
            {"agent": "patient_finance", "question": "What is the revenue by procedure group and site in the most recent month?", "rationale": "revenue at risk"},
        ]
    if ("referral" in ql and any(w in ql for w in ["grow", "growth", "rate"]) and
            any(w in ql for w in ["capacity", "first", "quarter", "staff", "wait"])):
        return [
            {"agent": "capacity", "question": "What is the average theatre utilisation by site?", "rationale": "which site is closest to capacity"},
            {"agent": "capacity", "question": "What is the theatre utilisation forecast by site for the next 90 days?", "rationale": "who hits capacity first"},
            {"agent": "capacity", "question": "What is the average bed occupancy by site?", "rationale": "bed capacity headroom"},
            {"agent": "throughput_flow", "question": "What is the average waiting time in weeks by site?", "rationale": "wait deterioration"},
            {"agent": "workforce", "question": "What is the staff count by grade and site?", "rationale": "staff delta needed"},
        ]
    return None


async def _decompose_and_route(question: str, history: list):
    # Deterministic scenario override first (contractually-fixed routing).
    plan = _scenario_plan(question)
    if plan:
        return plan

    sys = {
        "role": "system",
        "content": (
            "You are the orchestration planner for a Ramsay Health analytics assistant. "
            "You have four specialist Genie data agents:\n" + _routing_catalog() +
            "\n\nROUTING RULES (follow strictly — routing to an unneeded agent is an error):\n"
            "- patient_finance (Patient Activity & Finance): any question that COUNTS or SEGMENTS patients/referrals "
            "by demographic (age), service/specialty, payor, or RTT PATHWAY STATUS (e.g. 'admitted RTT pathway', "
            "'still waiting', cohort filters), and any revenue/margin/procedure-group question. A cohort count 'by hospital' "
            "belongs HERE, not to throughput.\n"
            "- throughput_flow (Throughput & Flow): ONLY questions about wait TIME/duration (weeks waiting), RTT breach "
            "PERCENTAGE, or theatre cases completed / patient flow rates. Not for cohort counts.\n"
            "- capacity (Capacity): theatre/bed UTILISATION, occupancy, diagnostic slots, spare capacity.\n"
            "- workforce (Workforce): staffing, fill rate, staff counts by grade, rostered hours. Only when the question "
            "explicitly needs staffing.\n"
            "Do NOT add agents 'for completeness'. Use the FEWEST agents that answer the question.\n"
            "- GROWTH / CAPACITY STRESS-TEST questions ('if referrals keep growing, which hospital hits theatre/bed "
            "capacity first', 'when do we run out of capacity', staffing to hold service): route to capacity (utilisation + "
            "forecast) + throughput_flow (waiting times) + workforce (staff delta). Do NOT route to patient_finance — the "
            "word 'referrals' here is a GROWTH DRIVER, not a revenue/cohort question.\n\n"
            "Given the user question, break it into the minimal set of sub-questions and assign each to exactly one agent. "
            "Prefer FEWER, focused sub-questions. If a comparison spans two metrics (e.g. capacity vs wait times), create one sub-question per metric routed to the right agent. "
            "IMPORTANT for reliable SQL generation: phrase each sub-question as a broad \"by site\" (or \"by service\"/\"by grade\") aggregation rather than naming two specific sites with \"versus\". "
            "For example, instead of \"utilisation for Site A versus Site B\", ask \"What is the average theatre utilisation by site?\". "
            "The comparison between specific sites is performed later during synthesis from the returned rows. "
            "Use plain metric names (e.g. \"average theatre utilisation\", \"RTT breach percentage\") and avoid parenthetical units like \"(%)\". "
            "For scenario / what-if questions (closing theatres, shifting activity between sites, cutting NHS volume, opening capacity, forecasting when capacity is hit), DO NOT send the scenario itself to an agent — agents only return CURRENT baseline data. Instead decompose into the SEPARATE baseline metrics scoped by DATE and SITE, routed across the RIGHT agents, each as a broad 'by site' or 'by specialty' aggregation. The scenario ARITHMETIC (cases lost, slack available elsewhere, shift plan, earliest low-impact window, margin at risk, before-vs-after) is computed later during synthesis. "
            "For example, for 'if I close 2 theatres for 3 days at Springfield starting 2026-09-14, what surgeries are impacted, can they shift elsewhere, and what is the earliest low-disruption date?' produce sub-questions like: "
            "(capacity) 'How many theatre cases are scheduled at Springfield between 2026-09-14 and 2026-09-16 by specialty?'; "
            "(capacity) 'What is the spare theatre capacity by site for the week of 2026-09-14?'; "
            "(capacity) 'What is the theatre utilisation forecast by site for the next 30 days?'; "
            "(throughput_flow) 'How many patients are on the waiting list by specialty and site?'; "
            "(patient_finance) 'What is the revenue and margin by procedure group and site for the last month?'. "
            "Prefer 4-6 focused sub-questions for a rich scenario, with DATE and SITE filters embedded in the question text (e.g., 'between 2026-09-14 and 2026-09-16'). "
            "For a GROWTH stress-test like 'if referrals keep growing at the current rate, which hospital hits theatre or bed capacity first over the next quarter, how many more staff would we need, and what happens to waiting times?' produce EXACTLY these sub-questions: "
            "(capacity) 'What is the average theatre utilisation by site?'; "
            "(capacity) 'What is the theatre utilisation forecast by site for the next 90 days?'; "
            "(capacity) 'What is the average bed occupancy by site?'; "
            "(throughput_flow) 'What is the average waiting time in weeks by site?'; "
            "(workforce) 'What is the staff count by grade and site?'. "
            "Do NOT route any part of a growth/capacity stress-test to patient_finance. "
            "Respond ONLY with JSON of the form: "
            "{\"subquestions\":[{\"question\":\"...\",\"agent\":\"capacity\",\"rationale\":\"short reason\"}]}. "
            "agent must be one of: " + ", ".join(SPACE_KEYS) + "."
        ),
    }
    hist = "\n".join(f"{m['role']}: {m['content']}" for m in (history or [])[-4:])
    user = {"role": "user",
            "content": (f"Recent conversation:\n{hist}\n\n" if hist else "") + f"User question: {question}"}
    raw = await chat([sys, user], max_tokens=800)
    parsed = parse_json(raw)
    subs = (parsed or {}).get("subquestions")
    if not isinstance(subs, list) or not subs:
        subs = [{"question": question, "agent": _keyword_route(question), "rationale": "fallback single route"}]
    out = []
    for s in subs:
        q = s.get("question") or question
        agent = s.get("agent") if s.get("agent") in SPACE_KEYS else _keyword_route(q)
        out.append({"question": q, "agent": agent, "rationale": s.get("rationale", "")})
    return out


async def _synthesize(question: str, results: list, guardrail: dict | None = None, staff_delta_md: str | None = None):
    blocks = []
    for i, r in enumerate(results):
        head = f"Sub-question {i+1} [{SPACES[r['agent']]['label']}]: {r['question']}"
        if r.get("error"):
            blocks.append(f"{head}\nERROR: {r['error']}")
            continue
        cols = r.get("columns") or []
        # Keep enough rows for full per-site×per-grade breakdowns (5 sites × 5 grades = 25).
        rows = (r.get("rows") or [])[:30]
        # Present the rows as a labelled table (header + separator) so the model formats cleanly.
        if cols and rows:
            tbl = ["| " + " | ".join(cols) + " |",
                   "| " + " | ".join("---" for _ in cols) + " |"]
            for row in rows:
                tbl.append("| " + " | ".join("" if c is None else str(c) for c in row) + " |")
            table_txt = "\n".join(tbl)
        else:
            table_txt = "(no rows)"
        blocks.append(f"{head}\nAgent note: {r.get('answer') or '(none)'}\nData:\n{table_txt}")
    joined = "\n\n".join(blocks)

    is_scenario = any(w in question.lower() for w in [
        "what if", "what happens", "close", "closure", "shift", "move ", "reduce",
        "increase", "unlock", "grow", "growth", "forecast", "when do we", "when will"])
    scenario_guide = (
        "This IS a what-if / scenario question. Do the arithmetic from the baseline rows — do NOT say a figure "
        "'cannot be quantified' if the inputs to estimate it are present; make a clearly-stated, reasonable estimate "
        "and show the calculation. Specifically:\n"
        "- Cases/sessions affected, and (only if money was asked) revenue at risk, from the baseline rows.\n"
        "- Spare capacity elsewhere from the utilisation rows.\n"
        "- STAFF DELTA: the constrained site's CURRENT staff-by-grade counts and its quarterly growth rate are in the "
        "data. Compute ABSOLUTE additional headcount per grade at that site: extra = ceil(current_count × quarterly_growth). "
        "Give whole numbers of people (e.g. 'RN: 35 → 38, +3'), NOT just a percentage. Present a table with columns "
        "Grade, Current, Additional, New total, and a total row. Use ONLY the constrained site's own counts. State the "
        "growth rate assumed. Never reply that staffing cannot be determined when staff-by-grade counts are present.\n"
        "- If work should move, give a concise allocation/shift plan as a markdown table (From site/specialty, Cases, "
        "To site, resulting utilisation). If timing is asked, give the earliest low-disruption window.\n"
        "Answer ONLY the parts the user actually asked — do not add sections they did not ask for."
        if is_scenario else
        "This is a straightforward data question. Answer it directly and stop — do NOT invent a scenario, "
        "shift plan, timing recommendation, or 'implications' section the user did not ask for.")

    sys = {
        "role": "system",
        "content": (
            "You are an executive analytics assistant for Ramsay Health (a UK independent-sector hospital group). "
            "Fuse the specialist agent results into ONE clear, executive-readable answer to the EXACT question asked. "
            "Answer ONLY what was asked — no boilerplate, no fixed template, no section the question doesn't call for. "
            "Do not narrate your process or the agents; give the answer.\n\n"
            "REGISTER: write in formal British English suitable for an NHS/independent-sector board — full sentences, "
            "no contractions, no casual phrasing, British spelling (utilisation, prioritise, theatre). "
            "NUMBER FORMAT: use a COMMA as the thousands separator (2,880 — never a space, never '2 880'). Money as "
            "£ with commas (£1,234,567). Percentages with a % sign to one decimal (72.9%). Wait times as 'weeks' or 'wk'. "
            "Theatre minutes as an integer followed by 'minutes'.\n\n"
            "FORMAT: Lead with a one-line direct answer. Then present the supporting figures. When the result is "
            "per-site / per-category / per-period data, render it as a clean GitHub-flavoured MARKDOWN TABLE with a "
            "header row, real hospital names, and formatted numbers: money as £ with thousands separators (e.g. "
            "£1,234,567), percentages with a % sign and one decimal, weeks as 'wk'. Right-size the table to the "
            "columns that answer the question — drop empty/irrelevant columns. For 2-4 headline numbers use short "
            "bullets instead of a table. Keep it tight; an executive should grasp it in seconds.\n"
            "ALWAYS use the real hospital names from the rows (Springfield, Ashtead, Pinehill, Rivers, Oaklands Hospital). "
            "NEVER use placeholders like 'Site A' / 'Site B'. NEVER invent numbers — use only values in the rows; if a "
            "row is missing a value, omit it rather than guessing.\n"
            "MONEY: only include revenue, margin, cost or any £ figures if the user EXPLICITLY asked about revenue, "
            "margin, cost, finance or money. If they did not, leave all monetary columns and figures out entirely — "
            "even if the agent data contains them.\n\n"
            f"{scenario_guide}\n\n"
            "End with a single italic '_Sources: <agent labels>_' line, then the chart block.\n\n"
            "ALWAYS append a fenced ```chart JSON block visualising the headline numbers of your answer — every answer "
            "gets a chart. Pick the chart type that best fits: 'bar' for one metric across sites/categories, "
            "'grouped-bar' for two metrics per site, 'line' for a trend/forecast, 'kpi' for a scenario delta or a "
            "single headline figure. Use ONLY numbers present in your answer.\n"
            "Schema: {\"chartType\":\"bar|line|pie|grouped-bar|kpi\",\"title\":\"...\",\"xField\":\"...\",\"yField\":\"...\" or [\"a\",\"b\"],\"series\":[\"..\"],\"data\":[{...}]}\n"
            "Rules: data must be an array of flat objects using ONLY numbers present in the results. "
            "For a single metric across several sites/categories use 'bar' (xField=the site/category, yField=the metric). "
            "For two metrics per site use 'grouped-bar' (yField as an array of the two metric keys). "
            "For a time trend/forecast use 'line'. "
            "For a scenario/what-if delta use 'kpi' with data like [{\"label\":\"Cases at risk\",\"value\":42,\"unit\":\"cases\"},{\"label\":\"Capacity available\",\"value\":38,\"unit\":\"cases\"}]. "
            "Give each data key a clean short name matching what you charted. Keep numbers raw (no percent signs inside values)."
        ),
    }
    gr = f"\n\nDETERMINISTIC GUARDRAIL — obey these caps exactly when proposing the allocation split:\n{guardrail['facts']}" if guardrail else ""
    sd = (f"\n\nSTAFF REQUIREMENT — the additional headcount has ALREADY been calculated for you. For the "
          f"'how many more staff' part, reproduce EXACTLY this markdown table (do not alter the numbers, do not "
          f"convert to percentages, do not omit it):\n{staff_delta_md}") if staff_delta_md else ""
    # If some agents failed, tell the model to synthesize from what succeeded and state gaps.
    failed = [SPACES[r['agent']]['label'] for r in results if r.get('error')]
    gap = (f"\n\nNOTE: these agents failed and returned no data: {', '.join(failed)}. "
           "Answer from the agents that DID succeed and explicitly state what is missing.") if failed else ""
    user = {"role": "user",
            "content": f"Original question: {question}\n\nSpecialist agent results:\n{joined}{gr}{sd}{gap}"}
    return await chat([sys, user], max_tokens=3000, temperature=0.3)


def _split_answer_and_chart(text: str):
    """Extract a ```chart JSON block if present; return (prose, chartSpec|None)."""
    if not text:
        return text, None
    blocks = list(re.finditer(r"```chart\s*([\s\S]*?)```", text))
    if not blocks:
        return text, None
    # Strip ALL chart blocks from the prose.
    prose = re.sub(r"```chart\s*[\s\S]*?```", "", text).strip()
    # Use the first block that parses into a valid spec.
    for m in blocks:
        spec = parse_json(m.group(1))
        if isinstance(spec, dict) and "chartType" in spec and isinstance(spec.get("data"), list) and spec["data"]:
            return prose, spec
    return prose, None


async def run_supervisor(question: str, history: list, emit):
    """Run the full pipeline. `emit(event: dict)` is a sync callback (buffered SSE)."""

    # ===== GENIE-FIRST: All questions route through agents =====
    emit({"stage": "decompose_start"})
    subs = await _decompose_and_route(question, history)
    emit({"stage": "decompose", "subquestions": [s["question"] for s in subs]})

    emit({"stage": "route", "routes": [
        {"question": s["question"], "agent": s["agent"],
         "agentLabel": SPACES[s["agent"]]["label"], "rationale": s["rationale"]}
        for s in subs]})

    emit({"stage": "agents_start", "count": len(subs)})

    async def run_one(s):
        emit({"stage": "agent_call_start", "agent": s["agent"],
              "agentLabel": SPACES[s["agent"]]["label"], "question": s["question"]})
        g = await ask_genie(SPACES[s["agent"]]["id"], s["question"])
        if g.get("error"):
            try:
                rephrase = await chat([
                    {"role": "system", "content": "Rewrite the analytics question into the simplest robust \"by site\" aggregation that a text-to-SQL system can answer reliably. Reply with ONLY the rewritten question."},
                    {"role": "user", "content": s["question"]},
                ], max_tokens=120)
                rq = (rephrase or "").strip().strip("\"'")
                if rq:
                    emit({"stage": "agent_retry", "agent": s["agent"],
                          "agentLabel": SPACES[s["agent"]]["label"], "question": rq})
                    g2 = await ask_genie(SPACES[s["agent"]]["id"], rq)
                    if not g2.get("error"):
                        g = g2
                        s["question"] = rq
            except Exception:
                pass
        card = {
            "agent": s["agent"], "agentLabel": SPACES[s["agent"]]["label"], "question": s["question"],
            "sql": g.get("sql"), "description": g.get("description"), "thoughts": g.get("thoughts"),
            "columns": g.get("columns"), "rows": (g.get("rows") or [])[:5], "rowCount": g.get("rowCount"),
            "latencyMs": g.get("latencyMs"), "answer": g.get("answer"), "error": g.get("error"),
        }
        emit({"stage": "agent_call_done", **card})
        return {**s, **g}

    async def run_one_safe(s):
        # Partial-synthesis on failure (SPEC §3.6): never let one sub-call abort the whole turn.
        try:
            return await run_one(s)
        except Exception as e:
            err = f"{type(e).__name__}: {str(e)[:200]}"
            emit({"stage": "agent_call_done", "agent": s["agent"],
                  "agentLabel": SPACES[s["agent"]]["label"], "question": s["question"],
                  "sql": None, "columns": [], "rows": [], "rowCount": 0,
                  "latencyMs": None, "answer": None, "error": err})
            return {**s, "error": err, "rows": [], "columns": []}

    results = await asyncio.gather(*[run_one_safe(s) for s in subs])

    # Growth stress-test: supply the per-site quarterly demand-growth rates so the model can
    # compute a concrete staff delta (else it says "cannot be quantified"). Sourced from the
    # demo's site profiles; scaled to a quarter (~ annual growth / 4).
    ql_g = question.lower()
    staff_delta_md = None
    if ("grow" in ql_g or "growth" in ql_g) and any(w in ql_g for w in ["capacity", "staff", "quarter", "first"]):
        import math
        growth_annual = {"0312": ("Springfield Hospital", 0.30), "0333": ("Ashtead Hospital", 0.22),
                         "0341": ("Pinehill Hospital", 0.14), "0304": ("Rivers Hospital", 0.08),
                         "0327": ("Oaklands Hospital", 0.05)}
        # Constrained site = highest growth (= Springfield). Compute ABSOLUTE staff delta deterministically
        # from its current per-grade counts (from the workforce sub-call) so the model just renders it.
        constrained_code, (constrained_name, g_annual) = "0312", growth_annual["0312"]
        gq = round(g_annual / 4 * 100, 1)
        staff_rows = []
        for r in results:
            if r.get("agent") == "workforce" and any("grade" in (c or "").lower() for c in (r.get("columns") or [])):
                for row in (r.get("rows") or []):
                    if str(row[0]) == constrained_code and len(row) >= 3:
                        cur = int(float(row[2])); add = math.ceil(cur * g_annual / 4)
                        staff_rows.append([row[1], cur, add, cur + add])
        emit({"stage": "context", "note": f"{constrained_name} quarterly demand growth {gq}% — staff delta computed deterministically."})
        if staff_rows:
            tot_cur = sum(r[1] for r in staff_rows); tot_add = sum(r[2] for r in staff_rows)
            md = ["| Grade | Current | Additional | New total |", "|---|---|---|---|"]
            for gr, cur, add, new in staff_rows:
                md.append(f"| {gr} | {cur} | +{add} | {new} |")
            md.append(f"| **Total** | **{tot_cur}** | **+{tot_add}** | **{tot_cur+tot_add}** |")
            staff_delta_md = "\n".join(md)
            results.append({"agent": "workforce",
                            "question": f"Deterministic staff delta at {constrained_name} for +{gq}% quarterly demand",
                            "columns": ["Grade", "Current", "Additional", "New total"],
                            "rows": staff_rows, "rowCount": len(staff_rows), "sql": None,
                            "latencyMs": 0, "error": None,
                            "answer": "Pre-computed staff delta (rendered separately by the system)."})

    # Deterministic allocation guardrail for theatre-closure scenarios (SPEC §3.5).
    guardrail = None
    if _is_closure_scenario(question):
        guardrail = _closure_guardrail(question)
        if guardrail:
            emit({"stage": "guardrail", "source": guardrail["source"],
                  "slack": guardrail["slack"], "totalSlackMinutes": guardrail["total"],
                  "note": "Allocation capped at each receiving site's live 3-day theatre slack; "
                          "quietest sites fill first, residual flagged if network is short."})

    # Scenario detection (Q3/Q4 style what-ifs) — surface a forecast/scenario step.
    ql = question.lower()
    if any(w in ql for w in ["what happens", "what if", "shift ", "reduce", "increase", "unlock", "forecast", "when do we", "when will"]):
        emit({"stage": "forecast", "note": "Scenario/forecast: computing deltas from Genie baseline rows during synthesis."})

    emit({"stage": "synthesize_start"})
    raw = await _synthesize(question, results, guardrail, staff_delta_md)
    prose, chart = _split_answer_and_chart(raw)
    emit({"stage": "synthesize",
          "sources": list(dict.fromkeys(SPACES[r["agent"]]["label"] for r in results)),
          "chart": chart})

    emit({"stage": "final", "answer": prose, "chart": chart})

    # Machine-readable per-turn record (SPEC §7 test harness requirement). This is the PRIMARY
    # oracle for t_supervisor.py Layer-A assertions: exact agents_called, per-agent SQL/rows,
    # guardrail events, failures, final answer text, chart spec.
    turn_record = {
        "question": question,
        "agents_called": sorted({SPACES[r["agent"]]["label"] for r in results}),
        "agent_keys_called": sorted({r["agent"] for r in results}),
        "per_agent": [{
            "agent": r["agent"], "agentLabel": SPACES[r["agent"]]["label"],
            "sub_question": r.get("question"), "sql": r.get("sql"),
            "row_preview": (r.get("rows") or [])[:5], "row_count": r.get("rowCount"),
            "latency_ms": r.get("latencyMs"), "error": r.get("error"),
        } for r in results],
        "guardrail_events": ([guardrail] if guardrail else []),
        "final_answer_text": prose,
        "chart_spec": chart,
    }
    emit({"stage": "turn_record", "record": turn_record})
    return {"finalAnswer": prose, "chart": chart, "results": results, "subs": subs,
            "turnRecord": turn_record}
