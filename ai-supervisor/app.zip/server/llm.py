"""gpt-oss-120b chat client via Databricks serving endpoint (OpenAI-compatible)."""
import json
import asyncio
import urllib.request
import urllib.error

from .config import HOST, LLM_ENDPOINT, get_token


def _extract_text(choice: dict) -> str:
    content = (choice or {}).get("message", {}).get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            p.get("text", "") for p in content
            if p.get("type") in ("text", "output_text")
        )
    return ""


def _chat_sync(messages, max_tokens=1200, temperature=0.2) -> str:
    body = json.dumps({"messages": messages, "max_tokens": max_tokens, "temperature": temperature}).encode()
    req = urllib.request.Request(
        f"{HOST}/serving-endpoints/{LLM_ENDPOINT}/invocations",
        data=body,
        headers={"Authorization": "Bearer " + get_token(), "Content-Type": "application/json"},
        method="POST",
    )
    try:
        j = json.loads(urllib.request.urlopen(req).read())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"LLM {e.code}: {e.read().decode()[:500]}")
    return _extract_text((j.get("choices") or [{}])[0])


async def chat(messages, max_tokens=1200, temperature=0.2) -> str:
    return await asyncio.to_thread(_chat_sync, messages, max_tokens, temperature)


def parse_json(text: str):
    """Robustly extract the first JSON object/array from an LLM reply."""
    if not text:
        return None
    import re
    fence = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    candidate = fence.group(1) if fence else text
    first = candidate.find("{")
    first_arr = candidate.find("[")
    start = first
    if first_arr != -1 and (first == -1 or first_arr < first):
        start = first_arr
    if start == -1:
        return None
    open_c = candidate[start]
    close_c = "}" if open_c == "{" else "]"
    depth = 0
    for i in range(start, len(candidate)):
        if candidate[i] == open_c:
            depth += 1
        elif candidate[i] == close_c:
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(candidate[start:i + 1])
                except Exception:
                    return None
    return None
