"""Dual-mode auth + config for the Ramsay AI Supervisor app.

Runtime (Databricks App): service-principal OAuth via client-credentials.
Local dev: Azure AD CLI token (`az account get-access-token`).
Token cached ~40 min in memory, never written to disk.
"""
import os
import time
import subprocess
import urllib.request
import urllib.parse

HOST = os.environ.get(
    "DATABRICKS_HOST_URL",
    "https://",
).rstrip("/")

WAREHOUSE_ID = os.environ.get("DATABRICKS_WAREHOUSE_ID", "886fd3b1e294db8c")
LLM_ENDPOINT = os.environ.get("LLM_ENDPOINT", "databricks-gpt-oss-120b")

SPACES = {
    "throughput_flow": {
        "id": os.environ.get("GENIE_THROUGHPUT_FLOW", "01f19d0660ed173badd699ea6259dda0"),
        "label": "Throughput & Flow",
        "desc": "RTT waiting times, breach percentages, theatre cases completed, patient flow, waiting lists by service and site.",
    },
    "patient_finance": {
        "id": os.environ.get("GENIE_PATIENT_FINANCE", "01f19d067c201db19bea1a72c60b57d1"),
        "label": "Patient Activity & Finance",
        "desc": "Referrals, patients by payor type, revenue by channel and procedure group, activity and financial performance.",
    },
    "workforce": {
        "id": os.environ.get("GENIE_WORKFORCE", "01f19d069acb1e56af7ef010253dffea"),
        "label": "Workforce",
        "desc": "Staffing fill rates, staff counts by grade, rostered hours, shift cover and workforce capacity.",
    },
    "capacity": {
        "id": os.environ.get("GENIE_CAPACITY", "01f19d06b56810f1bb0168285b36cb26"),
        "label": "Capacity",
        "desc": "Theatre and bed utilisation, occupancy, diagnostic slots available vs booked by modality, physical capacity by site.",
    },
}

AAD_RESOURCE = "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d"  # AzureDatabricks
IS_DATABRICKS_APP = bool(os.environ.get("DATABRICKS_CLIENT_ID") and os.environ.get("DATABRICKS_CLIENT_SECRET"))

_cache = {"tok": None, "at": 0.0}


def _az_token() -> str:
    return subprocess.run(
        ["az", "account", "get-access-token", "--resource", AAD_RESOURCE,
         "--query", "accessToken", "-o", "tsv"],
        capture_output=True, text=True, check=True,
    ).stdout.strip()


def _sp_oauth_token() -> str:
    data = urllib.parse.urlencode({
        "grant_type": "client_credentials",
        "client_id": os.environ["DATABRICKS_CLIENT_ID"],
        "client_secret": os.environ["DATABRICKS_CLIENT_SECRET"],
        "scope": "all-apis",
    }).encode()
    req = urllib.request.Request(
        f"{HOST}/oidc/v1/token", data=data,
        headers={"Content-Type": "application/x-www-form-urlencoded"}, method="POST",
    )
    import json
    return json.loads(urllib.request.urlopen(req).read())["access_token"]


def get_token() -> str:
    if _cache["tok"] and time.time() - _cache["at"] < 2400:
        return _cache["tok"]
    tok = _sp_oauth_token() if IS_DATABRICKS_APP else _az_token()
    _cache.update(tok=tok, at=time.time())
    return tok
