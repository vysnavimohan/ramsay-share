"""Flagship-answer cache + Genie pre-warm (SPEC §3.9 — #1 robustness investment).

- prewarm_spaces(): fire a cheap async ping at each of the 4 Genie spaces so the first
  live demo question does not pay cold-start latency.
- Flagship cache: the full SSE event list for each of the 4 scripted questions is captured
  the first time it runs cleanly, saved to disk, and replayed instantly on a matching
  question. Any improvised (non-flagship) question always runs live. If the cache is empty
  or the question is not a flagship, callers fall through to the live supervisor.

Matching is by a normalised fingerprint of the question so minor whitespace/case differences
still hit. The scripted demo questions live in FLAGSHIP_FINGERPRINTS.
"""
import json
import os
import re
import time

CACHE_DIR = os.environ.get("RAMSAY_CACHE_DIR", os.path.join(os.path.dirname(__file__), "..", "flagship_cache"))
os.makedirs(CACHE_DIR, exist_ok=True)


def _norm(q: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (q or "").lower()).strip()


# Distinctive substrings that identify each scripted flagship question (order-independent).
FLAGSHIP_KEYS = {
    "q1_closure": ["close 2 theatres", "springfield"],
    "q2_wait": ["lowest wait", "root cause"],
    "q3_growth": ["referrals keep growing", "capacity first"],
    "q4_cohort": ["over 55", "trauma and orthopaedics", "admitted rtt"],
}


def flagship_id(question: str):
    n = _norm(question)
    for fid, keys in FLAGSHIP_KEYS.items():
        if all(_norm(k) in n for k in keys):
            return fid
    return None


def _path(fid: str) -> str:
    return os.path.join(CACHE_DIR, f"{fid}.json")


def get_cached(question: str):
    """Return the cached SSE event list for a flagship question, or None."""
    fid = flagship_id(question)
    if not fid:
        return None
    p = _path(fid)
    if not os.path.exists(p):
        return None
    try:
        with open(p) as f:
            return json.load(f).get("events")
    except Exception:
        return None


def save_cache(question: str, events: list):
    """Persist a clean flagship run for instant replay. Only caches SUCCESSFUL runs
    (a turn_record with >=1 agent and no whole-turn error)."""
    fid = flagship_id(question)
    if not fid:
        return False
    rec = next((e.get("record") for e in events if e.get("stage") == "turn_record"), None)
    if not rec or not rec.get("agent_keys_called"):
        return False
    if any(e.get("stage") == "error" for e in events):
        return False
    try:
        with open(_path(fid), "w") as f:
            json.dump({"question": question, "events": events, "cachedAt": time.time()}, f, default=str)
        return True
    except Exception:
        return False


async def prewarm_spaces():
    """Fire a trivial question at each Genie space so first live latency is low.
    Best-effort: swallow all errors (pre-warm must never block startup)."""
    try:
        import asyncio
        from .config import SPACES
        from .genie import ask_genie

        async def ping(sid):
            try:
                await ask_genie(sid, "How many sites are there?")
            except Exception:
                pass
        await asyncio.gather(*[ping(v["id"]) for v in SPACES.values()])
    except Exception:
        pass
