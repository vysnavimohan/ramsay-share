"""Lakebase (Postgres) persistence for conversation memory + traces.

Primary: Lakebase instance 'ramsay-supervisor-lb' via psycopg, authenticated with
a short-lived Databricks database credential (OAuth). Tables:
  conversations(id, title, created_at, updated_at)
  messages(id, conversation_id, role, content, created_at)
  traces(id, conversation_id, turn_id, events jsonb, created_at)

Graceful fallback to in-memory demo mode if Lakebase is unreachable so the app
never hard-fails.
"""
import os
import json
import time
import uuid
import urllib.request
import urllib.error

from .config import HOST, get_token

INSTANCE = os.environ.get("LAKEBASE_INSTANCE", "ramsay-supervisor-lb")
PGHOST = os.environ.get("PGHOST", "ep-old-leaf-edsxriv0.database.uksouth.azuredatabricks.net")
PGPORT = int(os.environ.get("PGPORT", "5432"))
PGDATABASE = os.environ.get("PGDATABASE", "databricks_postgres")
# PG role: in the app this is the SP client id; locally it's the caller's username.
PGUSER = os.environ.get("PGUSER") or os.environ.get("DATABRICKS_CLIENT_ID") or os.environ.get("PGUSER_LOCAL")

_demo = {"on": False}
_mem = {"conversations": {}, "messages": {}, "traces": {}}
_cred = {"tok": None, "at": 0.0}


def _db_credential() -> str:
    """Mint a short-lived Postgres OAuth credential for the instance."""
    if _cred["tok"] and time.time() - _cred["at"] < 2400:
        return _cred["tok"]
    body = json.dumps({"instance_names": [INSTANCE], "request_id": str(uuid.uuid4())}).encode()
    req = urllib.request.Request(
        f"{HOST}/api/2.0/database/credentials", data=body,
        headers={"Authorization": "Bearer " + get_token(), "Content-Type": "application/json"},
        method="POST",
    )
    j = json.loads(urllib.request.urlopen(req).read())
    tok = j.get("token")
    _cred.update(tok=tok, at=time.time())
    return tok


def _connect():
    import psycopg
    user = PGUSER
    if not user:
        raise RuntimeError("No PGUSER/DATABRICKS_CLIENT_ID for Lakebase role")
    return psycopg.connect(
        host=PGHOST, port=PGPORT, dbname=PGDATABASE, user=user,
        password=_db_credential(), sslmode="require", connect_timeout=10,
    )


def _exec(sql: str, params=None, fetch=False):
    conn = _connect()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, params or ())
            rows = cur.fetchall() if fetch else None
            cols = [d[0] for d in cur.description] if (fetch and cur.description) else []
        conn.commit()
        if fetch:
            return [dict(zip(cols, r)) for r in rows]
        return None
    finally:
        conn.close()


def init_db():
    try:
        _exec("""CREATE TABLE IF NOT EXISTS conversations (
                   id TEXT PRIMARY KEY, title TEXT,
                   created_at TIMESTAMPTZ DEFAULT now(),
                   updated_at TIMESTAMPTZ DEFAULT now())""")
        _exec("""CREATE TABLE IF NOT EXISTS messages (
                   id TEXT PRIMARY KEY, conversation_id TEXT, role TEXT, content TEXT,
                   created_at TIMESTAMPTZ DEFAULT now())""")
        _exec("""CREATE TABLE IF NOT EXISTS traces (
                   id TEXT PRIMARY KEY, conversation_id TEXT, turn_id TEXT,
                   events JSONB, created_at TIMESTAMPTZ DEFAULT now())""")
        print(f"[db] Lakebase tables ready on {PGHOST}/{PGDATABASE}")
        return {"demoMode": False}
    except Exception as e:
        print(f"[db] Lakebase init failed -> demo mode: {e}")
        _demo["on"] = True
        return {"demoMode": True, "error": str(e)}


def is_demo() -> bool:
    return _demo["on"]


# ---- Conversations ----
def upsert_conversation(cid: str, title: str):
    if _demo["on"]:
        c = _mem["conversations"].get(cid, {"id": cid, "created_at": time.time()})
        if title and not c.get("title"):
            c["title"] = title
        c["updated_at"] = time.time()
        _mem["conversations"][cid] = c
        return
    try:
        _exec("""INSERT INTO conversations (id, title) VALUES (%s, %s)
                 ON CONFLICT (id) DO UPDATE SET
                   title = COALESCE(conversations.title, EXCLUDED.title),
                   updated_at = now()""", (cid, title))
    except Exception as e:
        print("[db] upsert_conversation:", e)


def list_conversations():
    if _demo["on"]:
        cs = sorted(_mem["conversations"].values(), key=lambda c: c.get("updated_at", 0), reverse=True)
        return [{"id": c["id"], "title": c.get("title") or "Untitled",
                 "updated_at": c.get("updated_at")} for c in cs]
    try:
        return _exec("""SELECT id, COALESCE(title,'Untitled') AS title, updated_at
                        FROM conversations ORDER BY updated_at DESC LIMIT 100""", fetch=True)
    except Exception:
        return []


def save_message(cid: str, role: str, content: str):
    if _demo["on"]:
        _mem["messages"].setdefault(cid, []).append(
            {"id": str(uuid.uuid4()), "role": role, "content": content, "created_at": time.time()})
        return
    try:
        _exec("INSERT INTO messages (id, conversation_id, role, content) VALUES (%s,%s,%s,%s)",
              (str(uuid.uuid4()), cid, role, content))
    except Exception as e:
        print("[db] save_message:", e)


def save_trace(cid: str, turn_id: str, events: list):
    if _demo["on"]:
        _mem["traces"].setdefault(cid, []).append(
            {"turn_id": turn_id, "events": events, "created_at": time.time()})
        return
    try:
        _exec("INSERT INTO traces (id, conversation_id, turn_id, events) VALUES (%s,%s,%s,%s)",
              (str(uuid.uuid4()), cid, turn_id, json.dumps(events)))
    except Exception as e:
        print("[db] save_trace:", e)


def get_history(cid: str):
    """Return ordered messages for a conversation."""
    if _demo["on"]:
        return [{"role": m["role"], "content": m["content"]} for m in _mem["messages"].get(cid, [])]
    try:
        return _exec("""SELECT role, content FROM messages
                        WHERE conversation_id=%s ORDER BY created_at""", (cid,), fetch=True)
    except Exception:
        return []


def get_transcript(cid: str):
    """Return messages + their saved trace events for replay."""
    msgs = get_history(cid)
    if _demo["on"]:
        traces = _mem["traces"].get(cid, [])
    else:
        try:
            traces = _exec("""SELECT turn_id, events, created_at FROM traces
                              WHERE conversation_id=%s ORDER BY created_at""", (cid,), fetch=True)
        except Exception:
            traces = []
    return {"messages": msgs, "traces": traces}
