// Supervisor state machine: decompose -> route -> parallel Genie calls -> synthesize.
// Emits trace events via an async callback for SSE streaming.
import { chat, parseJson } from './llm.js';
import { askGenie } from './genie.js';

export const SPACES = {
  throughput_flow: {
    id: process.env.GENIE_THROUGHPUT_FLOW || '01f19d0660ed173badd699ea6259dda0',
    label: 'Throughput & Flow',
    desc: 'RTT waiting times, breach percentages, theatre cases completed, patient flow, waiting lists by service and site.',
  },
  patient_finance: {
    id: process.env.GENIE_PATIENT_FINANCE || '01f19d067c201db19bea1a72c60b57d1',
    label: 'Patient Activity & Finance',
    desc: 'Referrals, patients by payor type, revenue by channel and procedure group, activity and financial performance.',
  },
  workforce: {
    id: process.env.GENIE_WORKFORCE || '01f19d069acb1e56af7ef010253dffea',
    label: 'Workforce',
    desc: 'Staffing fill rates, staff counts by grade, rostered hours, shift cover and workforce capacity.',
  },
  capacity: {
    id: process.env.GENIE_CAPACITY || '01f19d06b56810f1bb0168285b36cb26',
    label: 'Capacity',
    desc: 'Theatre and bed utilisation, occupancy, diagnostic slots available vs booked by modality, physical capacity by site.',
  },
};

const spaceKeys = Object.keys(SPACES);

function routingCatalog() {
  return spaceKeys.map((k) => `- ${k} (${SPACES[k].label}): ${SPACES[k].desc}`).join('\n');
}

async function decomposeAndRoute(question, history) {
  const sys = {
    role: 'system',
    content:
      'You are the orchestration planner for a Ramsay Health analytics assistant. ' +
      'You have four specialist Genie data agents:\n' +
      routingCatalog() +
      '\n\nGiven the user question, break it into the minimal set of sub-questions and assign each to exactly one agent. ' +
      'Prefer FEWER, focused sub-questions. If a comparison spans two metrics (e.g. capacity vs wait times), create one sub-question per metric routed to the right agent. ' +
      'IMPORTANT for reliable SQL generation: phrase each sub-question as a broad "by site" (or "by service"/"by grade") aggregation rather than naming two specific sites with "versus". ' +
      'For example, instead of "utilisation for Site A versus Site B", ask "What is the average theatre utilisation by site?". ' +
      'The comparison between specific sites is performed later during synthesis from the returned rows. ' +
      'Use plain metric names (e.g. "average theatre utilisation", "RTT breach percentage") and avoid parenthetical units like "(%)". ' +
      'Respond ONLY with JSON of the form: ' +
      '{"subquestions":[{"question":"...","agent":"capacity","rationale":"short reason"}]}. ' +
      'agent must be one of: ' + spaceKeys.join(', ') + '.',
  };
  const hist = (history || [])
    .slice(-4)
    .map((m) => `${m.role}: ${m.content}`)
    .join('\n');
  const user = {
    role: 'user',
    content: (hist ? `Recent conversation:\n${hist}\n\n` : '') + `User question: ${question}`,
  };
  const raw = await chat([sys, user], { maxTokens: 800 });
  const parsed = parseJson(raw);
  let subs = parsed?.subquestions;
  if (!Array.isArray(subs) || subs.length === 0) {
    // Fallback: single sub-question, naive keyword route.
    subs = [{ question, agent: keywordRoute(question), rationale: 'fallback single route' }];
  }
  // Validate agent keys.
  subs = subs.map((s) => ({
    question: s.question || question,
    agent: spaceKeys.includes(s.agent) ? s.agent : keywordRoute(s.question || question),
    rationale: s.rationale || '',
  }));
  return subs;
}

function keywordRoute(q) {
  const s = (q || '').toLowerCase();
  if (/util|occupanc|bed|theatre capacity|diagnostic|slot|capacity/.test(s)) return 'capacity';
  if (/staff|workforce|roster|fill rate|grade|shift|hours/.test(s)) return 'workforce';
  if (/revenue|payor|referral|finance|procedure|channel/.test(s)) return 'patient_finance';
  if (/wait|rtt|breach|throughput|flow|theatre case|waiting/.test(s)) return 'throughput_flow';
  return 'throughput_flow';
}

async function synthesize(question, results, history) {
  const blocks = results
    .map((r, i) => {
      const head = `Sub-question ${i + 1} [${SPACES[r.agent].label}]: ${r.question}`;
      if (r.error) return `${head}\nERROR: ${r.error}`;
      const preview = r.rows
        .slice(0, 12)
        .map((row) => row.join(' | '))
        .join('\n');
      return `${head}\nAnswer: ${r.answer || '(no text answer)'}\nColumns: ${r.columns.join(', ')}\nRows:\n${preview}`;
    })
    .join('\n\n');

  const sys = {
    role: 'system',
    content:
      'You are an executive analytics assistant for Ramsay Health (UK private hospitals). ' +
      'Fuse the specialist agent results into ONE clear, executive-readable answer. ' +
      'Be concise and quantitative: lead with the direct answer, use short bullet points with the actual numbers, ' +
      'and where two sites or metrics are compared, state the comparison explicitly. ' +
      'If the question refers to entities from earlier in the conversation (e.g. "those two", "that site"), ' +
      'resolve them from the conversation history and answer about THOSE specific entities, not the overall max/min. ' +
      'Do not invent numbers not present in the results. End with a one-line "Sources" listing the agents used.',
  };
  const hist = (history || [])
    .slice(-6)
    .map((m) => `${m.role}: ${m.content}`)
    .join('\n');
  const user = {
    role: 'user',
    content:
      (hist ? `Conversation so far:\n${hist}\n\n` : '') +
      `Current question: ${question}\n\nSpecialist agent results:\n${blocks}`,
  };
  return chat([sys, user], { maxTokens: 1400, temperature: 0.3 });
}

/**
 * Run the full supervisor pipeline, emitting trace events.
 * emit(event) where event = { stage, ... }.
 */
export async function runSupervisor({ question, history, emit }) {
  // Stage 1: Decompose
  emit({ stage: 'decompose_start' });
  const subs = await decomposeAndRoute(question, history);
  emit({ stage: 'decompose', subquestions: subs.map((s) => s.question) });

  // Stage 2: Route (labelled chips)
  emit({
    stage: 'route',
    routes: subs.map((s) => ({
      question: s.question,
      agent: s.agent,
      agentLabel: SPACES[s.agent].label,
      rationale: s.rationale,
    })),
  });

  // Stage 3: Parallel Genie calls, each emits a call card on completion.
  emit({ stage: 'agents_start', count: subs.length });
  const results = await Promise.all(
    subs.map(async (s) => {
      emit({ stage: 'agent_call_start', agent: s.agent, agentLabel: SPACES[s.agent].label, question: s.question });
      let g = await askGenie(SPACES[s.agent].id, s.question);
      // One retry with a simpler rephrase if the generated SQL errored.
      if (g.error) {
        try {
          const rephrase = await chat(
            [
              { role: 'system', content: 'Rewrite the analytics question into the simplest robust "by site" aggregation that a text-to-SQL system can answer reliably. Reply with ONLY the rewritten question.' },
              { role: 'user', content: s.question },
            ],
            { maxTokens: 120 },
          );
          const rq = (rephrase || '').trim().replace(/^["']|["']$/g, '');
          if (rq) {
            emit({ stage: 'agent_retry', agent: s.agent, agentLabel: SPACES[s.agent].label, question: rq });
            const g2 = await askGenie(SPACES[s.agent].id, rq);
            if (!g2.error) { g = g2; s.question = rq; }
          }
        } catch { /* keep original error */ }
      }
      const card = {
        agent: s.agent,
        agentLabel: SPACES[s.agent].label,
        question: s.question,
        sql: g.sql,
        description: g.description,
        thoughts: g.thoughts,
        columns: g.columns,
        rows: g.rows.slice(0, 20),
        rowCount: g.rowCount,
        latencyMs: g.latencyMs,
        answer: g.answer,
        error: g.error,
      };
      emit({ stage: 'agent_call_done', ...card });
      return { ...s, ...g };
    }),
  );

  // Stage 4: Synthesize
  emit({ stage: 'synthesize_start' });
  const finalAnswer = await synthesize(question, results, history);
  emit({
    stage: 'synthesize',
    sources: [...new Set(results.map((r) => SPACES[r.agent].label))],
  });

  // Stage 5: Final answer
  emit({ stage: 'final', answer: finalAnswer });

  return { finalAnswer, results, subs };
}
