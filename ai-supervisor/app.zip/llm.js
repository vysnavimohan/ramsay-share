// gpt-oss-120b chat client via Databricks serving endpoint (OpenAI-compatible).
import { getToken } from './auth.js';

const HOST = process.env.DATABRICKS_HOST_URL || 'https://adb-7405610211988135.15.azuredatabricks.net';
const ENDPOINT = process.env.LLM_ENDPOINT || 'databricks-gpt-oss-120b';

// gpt-oss returns content as an array of parts (reasoning + text). Flatten to text.
function extractText(choice) {
  const content = choice?.message?.content;
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    return content
      .filter((p) => p.type === 'text' || p.type === 'output_text')
      .map((p) => p.text || '')
      .join('');
  }
  return '';
}

export async function chat(messages, { maxTokens = 1200, temperature = 0.2 } = {}) {
  const tok = await getToken(HOST);
  const r = await fetch(`${HOST}/serving-endpoints/${ENDPOINT}/invocations`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages, max_tokens: maxTokens, temperature }),
  });
  if (!r.ok) throw new Error(`LLM ${r.status}: ${(await r.text()).slice(0, 500)}`);
  const j = await r.json();
  return extractText(j.choices?.[0]);
}

// Robust JSON extraction from an LLM reply that may wrap JSON in prose/fences.
export function parseJson(text) {
  if (!text) return null;
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const candidate = fence ? fence[1] : text;
  const first = candidate.indexOf('{');
  const firstArr = candidate.indexOf('[');
  let startIdx = first;
  if (firstArr !== -1 && (first === -1 || firstArr < first)) startIdx = firstArr;
  if (startIdx === -1) return null;
  // Find matching close by scanning.
  const open = candidate[startIdx];
  const close = open === '{' ? '}' : ']';
  let depth = 0;
  for (let i = startIdx; i < candidate.length; i++) {
    if (candidate[i] === open) depth++;
    else if (candidate[i] === close) {
      depth--;
      if (depth === 0) {
        try {
          return JSON.parse(candidate.slice(startIdx, i + 1));
        } catch {
          return null;
        }
      }
    }
  }
  return null;
}
