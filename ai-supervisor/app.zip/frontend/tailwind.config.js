/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ramsay: {
          50: '#eff8fb', 100: '#d6edf4', 200: '#b0dce9', 300: '#7ac3da',
          400: '#3ea1c3', 500: '#2384a8', 600: '#1e6b8d', 700: '#1d5673',
          800: '#1f485f', 900: '#1e3d51', 950: '#0f2735',
        },
        teal: {
          400: '#2dd4bf', 500: '#14b8a6', 600: '#0d9488',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 3px rgba(15,39,53,0.08), 0 1px 2px rgba(15,39,53,0.04)',
        soft: '0 4px 16px rgba(15,39,53,0.08)',
      },
    },
  },
  plugins: [],
};
