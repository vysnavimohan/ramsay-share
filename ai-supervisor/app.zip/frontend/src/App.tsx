import { useEffect, useRef, useState } from 'react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import {
  Activity, Send, Plus, MessageSquare, Sparkles, Stethoscope, Loader2,
  MessagesSquare, ArrowRightLeft, TrendingUp,
} from 'lucide-react';
import TracePanel, { TraceEvent } from './components/TracePanel';
import ChartView, { ChartSpec } from './components/ChartView';
import ShiftTab from './components/ShiftTab';
import ForecastTab from './components/ForecastTab';

interface Turn {
  id: string;
  question: string;
  events: TraceEvent[];
  answer: string;
  chart: ChartSpec | null;
  live: boolean;
}

interface Convo { id: string; title: string; updated_at?: any; }

const SUGGESTIONS = [
  'Compare capacity utilisation and wait times between Springfield Hospital and Ashtead Hospital.',
  'What happens to capacity, workforce costs, and total margin if we shift 10% of orthopaedic activity from Springfield Hospital to Ashtead Hospital?',
  'How much private activity capacity can we unlock at Rivers Hospital if we reduce NHS volume by 15%?',
  "If I close 2 theatres for 3 days at Springfield Hospital, which surgeries are impacted, can they shift to Ashtead or Oaklands, and what's the earliest low-disruption window?",
];

export default function App() {
  const [turns, setTurns] = useState<Turn[]>([]);
  const [convos, setConvos] = useState<Convo[]>([]);
  const [convId, setConvId] = useState<string>('');
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState<'chat' | 'shift' | 'forecast'>('chat');
  const scrollRef = useRef<HTMLDivElement>(null);

  const loadConvos = () =>
    fetch('/api/conversations').then((r) => r.json()).then(setConvos).catch(() => {});

  useEffect(() => { loadConvos(); }, []);
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [turns]);

  function newChat() {
    setConvId('');
    setTurns([]);
    setInput('');
  }

  async function openConvo(id: string) {
    setConvId(id);
    setBusy(false);
    try {
      const t = await fetch(`/api/conversations/${id}`).then((r) => r.json());
      const msgs = t.messages || [];
      const traces = (t.traces || []);
      // Reconstruct turns: pair each user msg with the following assistant msg + trace by order.
      const rebuilt: Turn[] = [];
      let ti = 0;
      for (let i = 0; i < msgs.length; i++) {
        if (msgs[i].role === 'user') {
          const events: TraceEvent[] = (traces[ti]?.events) || [];
          const finalEvt = events.find((e: TraceEvent) => e.stage === 'final');
          const answer = msgs[i + 1]?.role === 'assistant' ? msgs[i + 1].content : (finalEvt?.answer || '');
          rebuilt.push({
            id: `${id}-${i}`, question: msgs[i].content, events,
            answer, chart: (finalEvt?.chart as ChartSpec) || null, live: false,
          });
          ti++;
        }
      }
      setTurns(rebuilt);
    } catch { /* ignore */ }
  }

  function ask(q: string) {
    const question = q.trim();
    if (!question || busy) return;
    setInput('');
    setBusy(true);
    const turnId = `${Date.now()}`;
    setTurns((t) => [...t, { id: turnId, question, events: [], answer: '', chart: null, live: true }]);

    const params = new URLSearchParams({ q: question });
    if (convId) params.set('c', convId);
    const es = new EventSource(`/api/chat/stream?${params.toString()}`);

    const patch = (fn: (t: Turn) => Turn) =>
      setTurns((arr) => arr.map((t) => (t.id === turnId ? fn(t) : t)));

    es.onmessage = (ev) => {
      let e: TraceEvent;
      try { e = JSON.parse(ev.data); } catch { return; }

      if (e.stage === 'meta' && e.conversationId && !convId) setConvId(e.conversationId);
      if (e.stage === 'final') {
        patch((t) => ({ ...t, answer: e.answer || '', chart: (e.chart as ChartSpec) || null,
          events: [...t.events, e] }));
      } else {
        patch((t) => ({ ...t, events: [...t.events, e] }));
      }
      if (e.stage === 'done') {
        patch((t) => ({ ...t, live: false }));
        setBusy(false);
        es.close();
        loadConvos();
      }
    };
    es.onerror = () => {
      patch((t) => ({ ...t, live: false }));
      setBusy(false);
      es.close();
    };
  }

  return (
    <div className="flex h-screen overflow-hidden bg-[#f5f8fa] font-sans">
      {/* Sidebar */}
      <aside className="hidden w-72 shrink-0 flex-col border-r border-ramsay-100 bg-white md:flex">
        <div className="flex items-center gap-2 border-b border-ramsay-100 px-4 py-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-ramsay-500 to-teal-500 text-white shadow-soft">
            <Stethoscope className="h-5 w-5" />
          </div>
          <div>
            <div className="text-sm font-bold leading-tight text-ramsay-900">Ramsay Health</div>
            <div className="text-[11px] text-ramsay-400">AI Operations Supervisor</div>
          </div>
        </div>
        <div className="p-3">
          <button onClick={newChat} className="flex w-full items-center justify-center gap-2 rounded-lg bg-ramsay-600 px-3 py-2 text-sm font-semibold text-white shadow-soft transition hover:bg-ramsay-700">
            <Plus className="h-4 w-4" /> New conversation
          </button>
        </div>
        <div className="px-4 pb-1 text-[11px] font-bold uppercase tracking-wide text-ramsay-400">History</div>
        <div className="flex-1 space-y-1 overflow-y-auto px-2 pb-4">
          {convos.length === 0 && <div className="px-2 py-2 text-[12px] text-ramsay-300">No conversations yet</div>}
          {convos.map((c) => (
            <button key={c.id} onClick={() => openConvo(c.id)}
              className={`flex w-full items-start gap-2 rounded-lg px-2 py-2 text-left text-[13px] transition hover:bg-ramsay-50 ${convId === c.id ? 'bg-ramsay-50 font-semibold text-ramsay-800' : 'text-ramsay-600'}`}>
              <MessageSquare className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ramsay-300" />
              <span className="line-clamp-2 leading-snug">{c.title}</span>
            </button>
          ))}
        </div>
      </aside>

      {/* Main */}
      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex items-center gap-3 border-b border-ramsay-100 bg-white/80 px-6 py-3 backdrop-blur">
          <Activity className="h-5 w-5 text-ramsay-500" />
          <div>
            <h1 className="text-base font-bold text-ramsay-900">Ramsay Health — AI Operations Supervisor</h1>
            <p className="text-[12px] text-ramsay-400">Multi-agent orchestration across Throughput, Finance, Workforce & Capacity</p>
          </div>
          <span className="ml-auto inline-flex items-center gap-1.5 rounded-full bg-teal-50 px-2.5 py-1 text-[11px] font-semibold text-teal-700">
            <span className="h-1.5 w-1.5 rounded-full bg-teal-500" /> 4 Genie agents live
          </span>
        </header>

        {/* Tab bar */}
        <nav className="flex items-center gap-1 border-b border-ramsay-100 bg-white px-4 md:px-8">
          {([
            ['chat', 'Chat & Trace', MessagesSquare],
            ['shift', 'Shift Activity', ArrowRightLeft],
            ['forecast', 'Forecast', TrendingUp],
          ] as const).map(([key, label, Icon]) => (
            <button key={key} onClick={() => setTab(key)}
              className={`flex items-center gap-1.5 border-b-2 px-3 py-2.5 text-[13px] font-semibold transition ${
                tab === key ? 'border-ramsay-500 text-ramsay-700' : 'border-transparent text-ramsay-400 hover:text-ramsay-600'}`}>
              <Icon className="h-4 w-4" /> {label}
            </button>
          ))}
        </nav>

        {tab === 'shift' && <div className="flex-1 overflow-y-auto"><ShiftTab /></div>}
        {tab === 'forecast' && <div className="flex-1 overflow-y-auto"><ForecastTab /></div>}

        <div ref={scrollRef} className={`flex-1 overflow-y-auto px-4 py-6 md:px-8 ${tab === 'chat' ? '' : 'hidden'}`}>
          <div className="mx-auto max-w-3xl space-y-6">
            {turns.length === 0 && (
              <div className="mt-8 text-center">
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-ramsay-500 to-teal-500 text-white shadow-soft">
                  <Sparkles className="h-7 w-7" />
                </div>
                <h2 className="text-xl font-bold text-ramsay-900">Ask an operational question</h2>
                <p className="mx-auto mt-1 max-w-md text-sm text-ramsay-400">
                  The supervisor decomposes your question, routes each part to the right Genie specialist, and fuses the results — with a full thinking trace.
                </p>
                <div className="mx-auto mt-6 grid max-w-2xl gap-2 sm:grid-cols-2">
                  {SUGGESTIONS.map((s) => (
                    <button key={s} onClick={() => ask(s)}
                      className="rounded-xl border border-ramsay-100 bg-white px-4 py-3 text-left text-[13px] text-ramsay-700 shadow-card transition hover:border-ramsay-300 hover:shadow-soft">
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {turns.map((t) => (
              <div key={t.id} className="space-y-3">
                {/* Question bubble */}
                <div className="flex justify-end">
                  <div className="max-w-[85%] rounded-2xl rounded-br-md bg-ramsay-600 px-4 py-2.5 text-[14px] text-white shadow-soft">
                    {t.question}
                  </div>
                </div>

                {/* Trace */}
                <TracePanel events={t.events} live={t.live} />

                {/* Answer bubble */}
                {(t.answer || (!t.live && !t.answer)) && (
                  <div className="flex justify-start">
                    <div className="max-w-[92%] rounded-2xl rounded-tl-md border border-ramsay-100 bg-white px-4 py-3 shadow-card">
                      {t.answer ? (
                        <div className="prose-tight text-[14px] leading-relaxed text-ramsay-800">
                          <Markdown remarkPlugins={[remarkGfm]}>{t.answer}</Markdown>
                        </div>
                      ) : (
                        <div className="text-[13px] text-ramsay-400">No answer produced.</div>
                      )}
                      {t.chart && <ChartView spec={t.chart} />}
                    </div>
                  </div>
                )}

                {t.live && !t.answer && (
                  <div className="flex items-center gap-2 pl-1 text-[12px] text-ramsay-400">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" /> Supervisor is working…
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Composer */}
        <div className={`border-t border-ramsay-100 bg-white px-4 py-3 md:px-8 ${tab === 'chat' ? '' : 'hidden'}`}>
          <form
            onSubmit={(e) => { e.preventDefault(); ask(input); }}
            className="mx-auto flex max-w-3xl items-end gap-2 rounded-2xl border border-ramsay-200 bg-white p-1.5 shadow-card focus-within:border-ramsay-400">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ask(input); } }}
              rows={1}
              placeholder="Ask about capacity, wait times, workforce, revenue, or a what-if scenario…"
              className="max-h-32 flex-1 resize-none bg-transparent px-3 py-2 text-[14px] text-ramsay-800 outline-none placeholder:text-ramsay-300"
            />
            <button type="submit" disabled={busy || !input.trim()}
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-ramsay-600 text-white transition hover:bg-ramsay-700 disabled:opacity-40">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </button>
          </form>
          <p className="mx-auto mt-1.5 max-w-3xl text-center text-[11px] text-ramsay-300">
            Synthetic demonstration data · Ramsay Health UK · powered by Databricks Genie + gpt-oss-120b
          </p>
        </div>
      </div>
    </div>
  );
}
