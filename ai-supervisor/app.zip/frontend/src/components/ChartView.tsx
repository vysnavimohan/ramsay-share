import {
  ResponsiveContainer, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from 'recharts';

export interface ChartSpec {
  chartType: 'bar' | 'line' | 'pie' | 'grouped-bar' | 'kpi';
  title?: string;
  xField?: string;
  yField?: string | string[];
  series?: string[];
  data: any[];
}

const PALETTE = ['#2384a8', '#14b8a6', '#7ac3da', '#1d5673', '#3ea1c3', '#0d9488', '#b0dce9'];

function fmt(n: any) {
  if (typeof n !== 'number') return n;
  if (Math.abs(n) >= 1000) return n.toLocaleString(undefined, { maximumFractionDigits: 0 });
  return Math.round(n * 100) / 100;
}

function KpiTiles({ data }: { data: any[] }) {
  return (
    <div className="flex flex-wrap gap-3">
      {data.map((d, i) => {
        const val = d.value ?? d.y ?? d.amount;
        const unit = d.unit === 'GBP' ? '£' : '';
        const neg = typeof val === 'number' && val < 0;
        return (
          <div key={i} className="flex-1 min-w-[140px] rounded-xl border border-ramsay-100 bg-white px-4 py-3 shadow-card">
            <div className="text-xs font-medium uppercase tracking-wide text-ramsay-500">{d.label ?? d.name ?? `Metric ${i + 1}`}</div>
            <div className={`mt-1 text-2xl font-bold ${neg ? 'text-rose-600' : 'text-ramsay-800'}`}>
              {unit}{fmt(typeof val === 'number' ? Math.abs(val) : val)}{d.unit && d.unit !== 'GBP' ? ` ${d.unit}` : ''}
              {neg && <span className="ml-1 text-sm">▼</span>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default function ChartView({ spec }: { spec: ChartSpec }) {
  if (!spec || !Array.isArray(spec.data) || spec.data.length === 0) return null;

  const x = spec.xField || Object.keys(spec.data[0])[0];
  let ys: string[] = [];
  if (Array.isArray(spec.yField)) ys = spec.yField;
  else if (spec.series && spec.series.length) ys = spec.series;
  else if (spec.yField) ys = [spec.yField];
  else ys = Object.keys(spec.data[0]).filter((k) => k !== x && typeof spec.data[0][k] === 'number');

  const wrap = (child: JSX.Element) => (
    <div className="mt-3 rounded-xl border border-ramsay-100 bg-gradient-to-br from-white to-ramsay-50/40 p-3 shadow-card">
      {spec.title && <div className="mb-1 px-1 text-sm font-semibold text-ramsay-800">{spec.title}</div>}
      <div style={{ width: '100%', height: 260 }}>
        <ResponsiveContainer>{child}</ResponsiveContainer>
      </div>
    </div>
  );

  if (spec.chartType === 'kpi') {
    return (
      <div className="mt-3">
        {spec.title && <div className="mb-1 px-1 text-sm font-semibold text-ramsay-800">{spec.title}</div>}
        <KpiTiles data={spec.data} />
      </div>
    );
  }

  if (spec.chartType === 'pie') {
    const nameKey = x;
    const valKey = ys[0];
    return wrap(
      <PieChart>
        <Pie data={spec.data} dataKey={valKey} nameKey={nameKey} cx="50%" cy="50%" outerRadius={90} label>
          {spec.data.map((_, i) => <Cell key={i} fill={PALETTE[i % PALETTE.length]} />)}
        </Pie>
        <Tooltip formatter={fmt} />
        <Legend />
      </PieChart>,
    );
  }

  if (spec.chartType === 'line') {
    return wrap(
      <LineChart data={spec.data} margin={{ top: 8, right: 16, bottom: 4, left: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2ecf1" />
        <XAxis dataKey={x} tick={{ fontSize: 12, fill: '#1d5673' }} />
        <YAxis tick={{ fontSize: 12, fill: '#1d5673' }} tickFormatter={fmt} />
        <Tooltip formatter={fmt} />
        {ys.length > 1 && <Legend />}
        {ys.map((k, i) => (
          <Line key={k} type="monotone" dataKey={k} stroke={PALETTE[i % PALETTE.length]} strokeWidth={2.5} dot={{ r: 3 }} />
        ))}
      </LineChart>,
    );
  }

  // bar + grouped-bar
  return wrap(
    <BarChart data={spec.data} margin={{ top: 8, right: 16, bottom: 4, left: 0 }}>
      <CartesianGrid strokeDasharray="3 3" stroke="#e2ecf1" />
      <XAxis dataKey={x} tick={{ fontSize: 12, fill: '#1d5673' }} />
      <YAxis tick={{ fontSize: 12, fill: '#1d5673' }} tickFormatter={fmt} />
      <Tooltip formatter={fmt} />
      {ys.length > 1 && <Legend />}
      {ys.map((k, i) => (
        <Bar key={k} dataKey={k} fill={PALETTE[i % PALETTE.length]} radius={[4, 4, 0, 0]} />
      ))}
    </BarChart>,
  );
}
