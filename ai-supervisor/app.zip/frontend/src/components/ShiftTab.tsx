import { useEffect, useState } from 'react';
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from 'recharts';
import {
  ArrowRightLeft, Sparkles, CheckCircle2, AlertTriangle, Loader2, Calendar, Gauge,
} from 'lucide-react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import TracePanel, { TraceEvent } from './TracePanel';
import ChartView, { ChartSpec } from './ChartView';

interface Opts { sites: string[]; procedureGroups: string[]; }
interface ShiftResult {
  kpis: { casesShifted: number; revenueShifted: number; minutesMoved: number; feasible: boolean; infeasibleSites: string[]; residualMinutes: number; };
  perSite: any[];
  chart: { site: string; Before: number; After: number }[];
  perProcedure: { procedure: string; casesMoved: number; revenueMoved: number; minutesPerCase: number }[];
  clampEvents: { site: string; clampedMinutes: number; note: string }[];
  assumptions: any;
  narrative: string;
  error?: string;
}

const BAND_STYLE: Record<string, string> = {
  green: 'bg-emerald-100 text-emerald-700',
  amber: 'bg-amber-100 text-amber-700',
  red: 'bg-rose-100 text-rose-700',
};

function MultiSelect({ label, options, selected, onChange }: {
  label: string; options: string[]; selected: string[]; onChange: (v: string[]) => void;
}) {
  const toggle = (o: string) =>
    onChange(selected.includes(o) ? selected.filter((s) => s !== o) : [...selected, o]);
  return (
    <div>
      <div className="mb-1.5 text-[11px] font-bold uppercase tracking-wide text-ramsay-500">{label}</div>
      <div className="flex flex-wrap gap-1.5">
        {options.map((o) => (
          <button key={o} onClick={() => toggle(o)}
            className={`rounded-full border px-2.5 py-1 text-[12px] font-medium transition ${
              selected.includes(o)
                ? 'border-ramsay-500 bg-ramsay-500 text-white shadow-sm'
                : 'border-ramsay-200 bg-white text-ramsay-600 hover:border-ramsay-300'}`}>
            {o}
          </button>
        ))}
      </div>
    </div>
  );
}

const GBP = (n: number) => '£' + Math.round(n).toLocaleString();

export default function ShiftTab() {
  const [opts, setOpts] = useState<Opts | null>(null);
  const [sources, setSources] = useState<string[]>(['Springfield Hospital']);
  const [targets, setTargets] = useState<string[]>(['Ashtead Hospital', 'Oaklands Hospital']);
  const [procs, setProcs] = useState<string[]>(['Orthopaedic - Hip']);
  const [pct, setPct] = useState(10);
  const [useAverage, setUseAverage] = useState(true);
  // Default to a window that actually contains invoiced activity (data spans ~Mar–Nov 2025).
  const [dateFrom, setDateFrom] = useState('2025-10-01');
  const [dateTo, setDateTo] = useState('2025-10-31');
  const [res, setRes] = useState<ShiftResult | null>(null);
  const [loading, setLoading] = useState(false);

  // AI explain state
  const [events, setEvents] = useState<TraceEvent[]>([]);
  const [aiAnswer, setAiAnswer] = useState('');
  const [aiChart, setAiChart] = useState<ChartSpec | null>(null);
  const [aiLive, setAiLive] = useState(false);

  useEffect(() => { fetch('/api/shift/options').then((r) => r.json()).then(setOpts); }, []);

  async function compute() {
    setLoading(true); setRes(null);
    try {
      const r = await fetch('/api/shift/compute', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sources, targets, procedures: procs, pct, useAverage,
          dateFrom: useAverage ? null : dateFrom, dateTo: useAverage ? null : dateTo }),
      }).then((x) => x.json());
      setRes(r);
    } finally { setLoading(false); }
  }

  useEffect(() => { if (opts) compute(); /* eslint-disable-next-line */ }, [opts]);

  function explainWithAI() {
    if (!res?.narrative || aiLive) return;
    setEvents([]); setAiAnswer(''); setAiChart(null); setAiLive(true);
    const es = new EventSource(`/api/chat/stream?${new URLSearchParams({ q: res.narrative })}`);
    es.onmessage = (ev) => {
      let e: TraceEvent; try { e = JSON.parse(ev.data); } catch { return; }
      if (e.stage === 'final') { setAiAnswer(e.answer || ''); setAiChart((e.chart as ChartSpec) || null); }
      setEvents((arr) => [...arr, e]);
      if (e.stage === 'done') { setAiLive(false); es.close(); }
    };
    es.onerror = () => { setAiLive(false); es.close(); };
  }

  if (!opts) return <div className="p-8 text-center text-ramsay-400"><Loader2 className="mx-auto h-5 w-5 animate-spin" /></div>;

  const k = res?.kpis;
  return (
    <div className="mx-auto max-w-4xl space-y-5 px-4 py-6 md:px-8">
      <div>
        <h2 className="flex items-center gap-2 text-lg font-bold text-ramsay-900">
          <ArrowRightLeft className="h-5 w-5 text-ramsay-500" /> Shift Activity Between Sites
        </h2>
        <p className="text-[13px] text-ramsay-400">Model moving activity between hospitals — deterministic capacity &amp; margin math, with an AI narrative on demand.</p>
      </div>

      {/* Controls */}
      <div className="space-y-4 rounded-2xl border border-ramsay-100 bg-white p-5 shadow-card">
        <MultiSelect label="Source hospitals" options={opts.sites} selected={sources} onChange={setSources} />
        <MultiSelect label="Target hospitals" options={opts.sites} selected={targets} onChange={setTargets} />
        <MultiSelect label="Procedure groups" options={opts.procedureGroups} selected={procs} onChange={setProcs} />

        <div className="flex flex-wrap items-center gap-6">
          <div className="min-w-[240px] flex-1">
            <div className="mb-1 flex items-center justify-between text-[11px] font-bold uppercase tracking-wide text-ramsay-500">
              <span>% of source activity to shift</span>
              <span className="text-ramsay-700">{pct}%</span>
            </div>
            <input type="range" min={0} max={100} value={pct} onChange={(e) => setPct(+e.target.value)}
              className="w-full accent-ramsay-500" />
          </div>
          <div>
            <div className="mb-1 text-[11px] font-bold uppercase tracking-wide text-ramsay-500">Capacity basis</div>
            <div className="flex rounded-lg border border-ramsay-200 p-0.5 text-[12px]">
              <button onClick={() => setUseAverage(true)}
                className={`flex items-center gap-1 rounded-md px-2.5 py-1 font-medium ${useAverage ? 'bg-ramsay-500 text-white' : 'text-ramsay-600'}`}>
                <Gauge className="h-3.5 w-3.5" /> Average stats
              </button>
              <button onClick={() => setUseAverage(false)}
                className={`flex items-center gap-1 rounded-md px-2.5 py-1 font-medium ${!useAverage ? 'bg-ramsay-500 text-white' : 'text-ramsay-600'}`}>
                <Calendar className="h-3.5 w-3.5" /> Date range
              </button>
            </div>
          </div>
          {!useAverage && (
            <div className="flex items-end gap-2">
              <div>
                <div className="mb-1 text-[10px] font-semibold uppercase text-ramsay-400">From</div>
                <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)}
                  className="rounded-lg border border-ramsay-200 px-2 py-1 text-[12px] text-ramsay-700" />
              </div>
              <div>
                <div className="mb-1 text-[10px] font-semibold uppercase text-ramsay-400">To</div>
                <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)}
                  className="rounded-lg border border-ramsay-200 px-2 py-1 text-[12px] text-ramsay-700" />
              </div>
            </div>
          )}
        </div>

        <div className="flex gap-2 pt-1">
          <button onClick={compute} disabled={loading}
            className="flex items-center gap-2 rounded-lg bg-ramsay-600 px-4 py-2 text-sm font-semibold text-white shadow-soft transition hover:bg-ramsay-700 disabled:opacity-50">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Gauge className="h-4 w-4" />} Calculate impact
          </button>
          <button onClick={explainWithAI} disabled={!res || aiLive}
            className="flex items-center gap-2 rounded-lg border border-ramsay-300 bg-white px-4 py-2 text-sm font-semibold text-ramsay-700 transition hover:border-ramsay-400 disabled:opacity-50">
            {aiLive ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4 text-teal-600" />} Explain with AI
          </button>
        </div>
      </div>

      {res?.error && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{res.error}</div>
      )}

      {/* KPI row + feasibility */}
      {k && (
        <>
          {k.casesShifted === 0 && !useAverage && (
            <div className="rounded-xl border border-sky-200 bg-sky-50 px-4 py-2 text-[12px] text-sky-800">
              No activity found in {dateFrom} → {dateTo} for the selected sites/procedures. Invoiced data runs ~Mar–Nov 2025 — pick a date range inside that window, or switch to “Average stats”.
            </div>
          )}
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
            <Kpi label="Cases shifted" value={Math.round(k.casesShifted).toLocaleString()} />
            <Kpi label="Theatre minutes moved" value={Math.round(k.minutesMoved).toLocaleString()} />
            <div className={`rounded-xl border px-4 py-3 shadow-card ${k.feasible ? 'border-teal-200 bg-teal-50' : 'border-amber-200 bg-amber-50'}`}>
              <div className="text-xs font-medium uppercase tracking-wide text-ramsay-500">Feasibility</div>
              <div className={`mt-1 flex items-center gap-1.5 text-lg font-bold ${k.feasible ? 'text-teal-700' : 'text-amber-700'}`}>
                {k.feasible ? <><CheckCircle2 className="h-5 w-5" /> Absorbable</> : <><AlertTriangle className="h-5 w-5" /> Over capacity</>}
              </div>
              {!k.feasible && k.infeasibleSites.length > 0 && <div className="mt-0.5 text-[11px] text-amber-700">At capacity: {k.infeasibleSites.join(', ')}</div>}
              {k.residualMinutes > 1 && <div className="mt-0.5 text-[11px] text-rose-700">{Math.round(k.residualMinutes).toLocaleString()} theatre min cannot be absorbed by targets</div>}
            </div>
          </div>

          {/* Guardrail clamp events */}
          {res!.clampEvents && res!.clampEvents.length > 0 && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-2 text-[12px] text-amber-800">
              <span className="font-semibold">Capacity guardrail:</span>{' '}
              {res!.clampEvents.map((c, i) => <span key={i}>{c.note}. </span>)}
            </div>
          )}

          {/* Before/after grouped bar */}
          <div className="rounded-2xl border border-ramsay-100 bg-white p-4 shadow-card">
            <div className="mb-2 text-sm font-semibold text-ramsay-800">Theatre utilisation — before vs after shift</div>
            <div style={{ width: '100%', height: 280 }}>
              <ResponsiveContainer>
                <BarChart data={res!.chart} margin={{ top: 8, right: 16, bottom: 4, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2ecf1" />
                  <XAxis dataKey="site" tick={{ fontSize: 11, fill: '#1d5673' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#1d5673' }} unit="%" />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="Before" fill="#7ac3da" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="After" fill="#2384a8" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Per-site + per-procedure tables */}
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-2xl border border-ramsay-100 bg-white p-4 shadow-card">
              <div className="mb-2 text-sm font-semibold text-ramsay-800">Per-site impact</div>
              <table className="w-full text-[12px]">
                <thead className="text-ramsay-500"><tr>
                  <th className="text-left font-semibold">Site</th><th className="text-left font-semibold">Role</th>
                  <th className="text-right font-semibold">Util →</th><th className="text-center font-semibold">Band</th>
                  <th className="text-right font-semibold">Wait →</th>
                </tr></thead>
                <tbody>
                  {res!.perSite.map((p, i) => (
                    <tr key={i} className="border-t border-ramsay-50">
                      <td className="py-1 text-ramsay-800">{p.site}</td>
                      <td className="py-1"><span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${p.role === 'source' ? 'bg-sky-100 text-sky-700' : 'bg-emerald-100 text-emerald-700'}`}>{p.role}</span></td>
                      <td className="py-1 text-right text-ramsay-800"><span className="text-ramsay-500">{p.utilBefore}%</span> → <span className="font-semibold">{p.utilAfter}%</span></td>
                      <td className="py-1 text-center"><span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${BAND_STYLE[p.bandAfter] || ''}`}>{p.bandAfter}</span></td>
                      <td className="py-1 text-right text-ramsay-800"><span className="text-ramsay-500">{p.waitBefore}w</span> → <span className="font-semibold">{p.waitAfter}w</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="rounded-2xl border border-ramsay-100 bg-white p-4 shadow-card">
              <div className="mb-2 text-sm font-semibold text-ramsay-800">Activity moved by procedure</div>
              <table className="w-full text-[12px]">
                <thead className="text-ramsay-500"><tr>
                  <th className="text-left font-semibold">Procedure</th>
                  <th className="text-right font-semibold">Cases</th><th className="text-right font-semibold">Revenue</th>
                </tr></thead>
                <tbody>
                  {res!.perProcedure.map((p, i) => (
                    <tr key={i} className="border-t border-ramsay-50">
                      <td className="py-1 text-ramsay-800">{p.procedure}</td>
                      <td className="py-1 text-right text-ramsay-600">{Math.round(p.casesMoved).toLocaleString()}</td>
                      <td className="py-1 text-right font-semibold text-ramsay-800">{GBP(p.revenueMoved)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="mt-2 text-[11px] text-ramsay-400">
                Capacity basis: {res!.assumptions.capacityBasis} · per-procedure minutes (hip 120, cataract 25) · amber ≥{res!.assumptions.amberAt}% util, red ≥{res!.assumptions.redAt}%
              </div>
            </div>
          </div>
        </>
      )}

      {/* AI narrative */}
      {(events.length > 0 || aiAnswer) && (
        <div className="space-y-3 rounded-2xl border border-teal-100 bg-teal-50/30 p-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-ramsay-800">
            <Sparkles className="h-4 w-4 text-teal-600" /> AI narrative
          </div>
          <div className="text-[12px] italic text-ramsay-500">"{res?.narrative}"</div>
          <TracePanel events={events} live={aiLive} />
          {aiAnswer && (
            <div className="rounded-xl border border-ramsay-100 bg-white p-4 shadow-card">
              <div className="prose-tight text-[14px] leading-relaxed text-ramsay-800">
                <Markdown remarkPlugins={[remarkGfm]}>{aiAnswer}</Markdown>
              </div>
              {aiChart && <ChartView spec={aiChart} />}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Kpi({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-ramsay-100 bg-white px-4 py-3 shadow-card">
      <div className="text-xs font-medium uppercase tracking-wide text-ramsay-500">{label}</div>
      <div className="mt-1 text-2xl font-bold text-ramsay-800">{value}</div>
    </div>
  );
}
