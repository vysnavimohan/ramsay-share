import { useEffect, useMemo, useState } from 'react';
import {
  ResponsiveContainer, ComposedChart, Area, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ReferenceLine,
} from 'recharts';
import { TrendingUp, Loader2, Clock } from 'lucide-react';

const SITES = ['Rivers Hospital', 'Ashtead Hospital', 'Springfield Hospital', 'Oaklands Hospital', 'Pinehill Hospital'];
const COLORS = ['#2384a8', '#14b8a6', '#7ac3da', '#1d5673', '#3ea1c3'];

interface Point { date: string; value: number; lower?: number; upper?: number; }
interface FData {
  today: string;
  util: Record<string, Point[]>;
  wait: Record<string, Point[]>;
  utilHistory: Record<string, Point[]>;
  error?: string;
}

// Merge multiple sites' series into a single recharts dataset keyed by date.
function mergeSeries(byname: Record<string, Point[]>, sites: string[], band: boolean) {
  const map: Record<string, any> = {};
  sites.forEach((s) => {
    (byname[s] || []).forEach((p) => {
      map[p.date] = map[p.date] || { date: p.date };
      map[p.date][s] = p.value;
      if (band && p.lower != null) {
        map[p.date][`${s}__lo`] = p.lower;
        map[p.date][`${s}__band`] = (p.upper ?? p.value) - (p.lower ?? p.value);
      }
    });
  });
  return Object.values(map).sort((a: any, b: any) => a.date.localeCompare(b.date));
}

function ForecastChart({ title, unit, data, sites, today }: {
  title: string; unit: string; data: any[]; sites: string[]; today: string;
}) {
  return (
    <div className="rounded-2xl border border-ramsay-100 bg-white p-4 shadow-card">
      <div className="mb-2 text-sm font-semibold text-ramsay-800">{title}</div>
      <div style={{ width: '100%', height: 300 }}>
        <ResponsiveContainer>
          <ComposedChart data={data} margin={{ top: 8, right: 16, bottom: 4, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2ecf1" />
            <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#1d5673' }} minTickGap={40} />
            <YAxis tick={{ fontSize: 11, fill: '#1d5673' }} unit={unit} domain={['auto', 'auto']} />
            <Tooltip />
            <Legend />
            {sites.map((s, i) => [
              // invisible base to lift the band
              <Area key={`${s}-lo`} dataKey={`${s}__lo`} stackId={s} stroke="none" fill="none" legendType="none" tooltipType="none" />,
              <Area key={`${s}-band`} dataKey={`${s}__band`} stackId={s} stroke="none"
                fill={COLORS[i % COLORS.length]} fillOpacity={0.12} legendType="none" tooltipType="none" name={`${s} band`} />,
              <Line key={s} dataKey={s} stroke={COLORS[i % COLORS.length]} strokeWidth={2.5} dot={false} name={s} />,
            ])}
            <ReferenceLine x={today} stroke="#0f2735" strokeDasharray="4 4"
              label={{ value: 'today', position: 'insideTopRight', fontSize: 10, fill: '#0f2735' }} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default function ForecastTab() {
  const [sites, setSites] = useState<string[]>(['Springfield Hospital', 'Ashtead Hospital']);
  const [data, setData] = useState<FData | null>(null);
  const [loading, setLoading] = useState(false);

  function load() {
    setLoading(true);
    fetch(`/api/forecast?sites=${encodeURIComponent(sites.join(','))}`)
      .then((r) => r.json()).then(setData).finally(() => setLoading(false));
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [sites]);

  const utilData = useMemo(() => data ? mergeSeries(data.util, sites, true) : [], [data, sites]);
  const waitData = useMemo(() => data ? mergeSeries(data.wait, sites, true) : [], [data, sites]);

  const toggle = (s: string) =>
    setSites(sites.includes(s) ? sites.filter((x) => x !== s) : [...sites, s]);

  return (
    <div className="mx-auto max-w-4xl space-y-5 px-4 py-6 md:px-8">
      <div>
        <h2 className="flex items-center gap-2 text-lg font-bold text-ramsay-900">
          <TrendingUp className="h-5 w-5 text-ramsay-500" /> Forecast — same-rate projection
        </h2>
        <p className="text-[13px] text-ramsay-400">Theatre utilisation &amp; RTT wait times projected forward at the current run-rate, with confidence bands.</p>
      </div>

      <div className="rounded-2xl border border-ramsay-100 bg-white p-4 shadow-card">
        <div className="mb-1.5 text-[11px] font-bold uppercase tracking-wide text-ramsay-500">Hospitals</div>
        <div className="flex flex-wrap gap-1.5">
          {SITES.map((s) => (
            <button key={s} onClick={() => toggle(s)}
              className={`rounded-full border px-2.5 py-1 text-[12px] font-medium transition ${
                sites.includes(s) ? 'border-ramsay-500 bg-ramsay-500 text-white' : 'border-ramsay-200 bg-white text-ramsay-600 hover:border-ramsay-300'}`}>
              {s}
            </button>
          ))}
        </div>
      </div>

      {loading && <div className="p-8 text-center text-ramsay-400"><Loader2 className="mx-auto h-5 w-5 animate-spin" /></div>}
      {data?.error && <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">{data.error}</div>}

      {data && !loading && (
        <>
          <div className="flex items-center gap-1.5 text-[12px] text-ramsay-400">
            <Clock className="h-3.5 w-3.5" /> Forecast anchored at {data.today}; shaded bands = lower/upper confidence.
          </div>
          <ForecastChart title="Projected theatre utilisation (%)" unit="%" data={utilData} sites={sites} today={data.today} />
          <ForecastChart title="Projected average RTT wait (weeks)" unit="w" data={waitData} sites={sites} today={data.today} />
        </>
      )}
    </div>
  );
}
