import { useState } from 'react';
import {
  Brain, GitBranch, Database, Sparkles, CheckCircle2, AlertTriangle,
  ChevronDown, ChevronRight, Clock, TrendingUp, Loader2,
} from 'lucide-react';

export interface TraceEvent {
  stage: string;
  [k: string]: any;
}

const AGENT_COLORS: Record<string, string> = {
  throughput_flow: 'bg-sky-100 text-sky-700 border-sky-200',
  patient_finance: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  workforce: 'bg-violet-100 text-violet-700 border-violet-200',
  capacity: 'bg-amber-100 text-amber-700 border-amber-200',
};

function StageIcon({ stage }: { stage: string }) {
  const c = 'w-4 h-4';
  if (stage.startsWith('decompose')) return <Brain className={`${c} text-ramsay-500`} />;
  if (stage === 'route') return <GitBranch className={`${c} text-ramsay-500`} />;
  if (stage.startsWith('agent')) return <Database className={`${c} text-ramsay-500`} />;
  if (stage === 'forecast') return <TrendingUp className={`${c} text-teal-600`} />;
  if (stage.startsWith('synthesize')) return <Sparkles className={`${c} text-ramsay-500`} />;
  if (stage === 'final' || stage === 'done') return <CheckCircle2 className={`${c} text-teal-600`} />;
  if (stage === 'error') return <AlertTriangle className={`${c} text-rose-600`} />;
  return <Clock className={c} />;
}

function AgentChip({ agent, label }: { agent: string; label: string }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-semibold ${AGENT_COLORS[agent] || 'bg-slate-100 text-slate-700 border-slate-200'}`}>
      {label}
    </span>
  );
}

function CallCard({ e }: { e: TraceEvent }) {
  const [open, setOpen] = useState(false);
  const err = !!e.error;
  return (
    <div className={`rounded-lg border ${err ? 'border-rose-200 bg-rose-50/50' : 'border-ramsay-100 bg-white'} p-2.5 shadow-card`}>
      <button onClick={() => setOpen(!open)} className="flex w-full items-start gap-2 text-left">
        {open ? <ChevronDown className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ramsay-400" /> : <ChevronRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ramsay-400" />}
        <div className="flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <AgentChip agent={e.agent} label={e.agentLabel} />
            {typeof e.latencyMs === 'number' && (
              <span className="inline-flex items-center gap-0.5 text-[11px] text-ramsay-400"><Clock className="h-3 w-3" />{(e.latencyMs / 1000).toFixed(1)}s</span>
            )}
            {err && <span className="text-[11px] font-semibold text-rose-600">error</span>}
            {!err && typeof e.rowCount === 'number' && <span className="text-[11px] text-ramsay-400">{e.rowCount} rows</span>}
          </div>
          <div className="mt-1 text-[13px] leading-snug text-ramsay-800">{e.question}</div>
        </div>
      </button>
      {open && (
        <div className="mt-2 space-y-2 pl-5">
          {err && <div className="rounded bg-rose-100 px-2 py-1 text-[12px] text-rose-700">{e.error}</div>}
          {e.sql && (
            <div>
              <div className="mb-0.5 text-[10px] font-semibold uppercase tracking-wide text-ramsay-400">Generated SQL</div>
              <pre className="overflow-x-auto rounded bg-ramsay-950 p-2 text-[11px] leading-relaxed text-ramsay-100">{e.sql}</pre>
            </div>
          )}
          {Array.isArray(e.columns) && e.columns.length > 0 && Array.isArray(e.rows) && e.rows.length > 0 && (
            <div>
              <div className="mb-0.5 text-[10px] font-semibold uppercase tracking-wide text-ramsay-400">Returned rows (preview)</div>
              <div className="overflow-x-auto rounded border border-ramsay-100">
                <table className="w-full text-[11px]">
                  <thead className="bg-ramsay-50 text-ramsay-600">
                    <tr>{e.columns.map((c: string) => <th key={c} className="px-2 py-1 text-left font-semibold">{c}</th>)}</tr>
                  </thead>
                  <tbody>
                    {e.rows.slice(0, 6).map((r: any[], i: number) => (
                      <tr key={i} className="border-t border-ramsay-50">
                        {r.map((v, j) => <td key={j} className="px-2 py-1 text-ramsay-700">{v == null ? '' : String(v)}</td>)}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function TracePanel({ events, live }: { events: TraceEvent[]; live: boolean }) {
  const [collapsed, setCollapsed] = useState(false);
  if (!events || events.length === 0) return null;

  const decompose = events.find((e) => e.stage === 'decompose');
  const route = events.find((e) => e.stage === 'route');
  const calls = events.filter((e) => e.stage === 'agent_call_done');
  const retries = events.filter((e) => e.stage === 'agent_retry');
  const forecast = events.find((e) => e.stage === 'forecast');
  const synth = events.find((e) => e.stage === 'synthesize');
  const errEvt = events.find((e) => e.stage === 'error');
  const done = events.some((e) => e.stage === 'done');

  const currentStage = events[events.length - 1]?.stage;
  const inProgressLabel: Record<string, string> = {
    decompose_start: 'Decomposing question…',
    decompose: 'Routing to agents…',
    route: 'Calling specialist agents…',
    agents_start: 'Calling specialist agents…',
    agent_call_start: 'Querying Genie agents…',
    agent_retry: 'Retrying with simpler query…',
    agent_call_done: 'Gathering results…',
    forecast: 'Computing scenario deltas…',
    synthesize_start: 'Synthesising executive answer…',
    synthesize: 'Finalising…',
  };

  return (
    <div className="rounded-xl border border-ramsay-100 bg-ramsay-50/40 shadow-card">
      <button onClick={() => setCollapsed(!collapsed)} className="flex w-full items-center gap-2 border-b border-ramsay-100 px-3 py-2">
        <Brain className="h-4 w-4 text-ramsay-600" />
        <span className="text-sm font-semibold text-ramsay-800">Thinking trace</span>
        {live && !done && (
          <span className="inline-flex items-center gap-1 text-[11px] text-teal-600">
            <Loader2 className="h-3 w-3 animate-spin" />
            {inProgressLabel[currentStage] || 'Working…'}
          </span>
        )}
        {done && <span className="text-[11px] text-ramsay-400">complete</span>}
        <span className="ml-auto">{collapsed ? <ChevronRight className="h-4 w-4 text-ramsay-400" /> : <ChevronDown className="h-4 w-4 text-ramsay-400" />}</span>
      </button>

      {!collapsed && (
        <div className="space-y-3 p-3">
          {/* DECOMPOSE */}
          {decompose && (
            <div className="animate-fadeUp">
              <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-ramsay-500"><StageIcon stage="decompose" /> Decompose</div>
              <ol className="space-y-1 pl-1">
                {decompose.subquestions.map((q: string, i: number) => (
                  <li key={i} className="flex gap-2 text-[13px] text-ramsay-700">
                    <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-ramsay-200 text-[10px] font-bold text-ramsay-700">{i + 1}</span>
                    {q}
                  </li>
                ))}
              </ol>
            </div>
          )}

          {/* ROUTE */}
          {route && (
            <div className="animate-fadeUp">
              <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-ramsay-500"><StageIcon stage="route" /> Route</div>
              <div className="space-y-1.5">
                {route.routes.map((r: any, i: number) => (
                  <div key={i} className="flex flex-wrap items-center gap-1.5 text-[12px]">
                    <AgentChip agent={r.agent} label={r.agentLabel} />
                    <span className="text-ramsay-400">{r.rationale}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* AGENT CALLS */}
          {(calls.length > 0 || retries.length > 0) && (
            <div className="animate-fadeUp">
              <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-ramsay-500"><StageIcon stage="agent" /> Agent calls</div>
              <div className="space-y-1.5">
                {calls.map((e, i) => <CallCard key={i} e={e} />)}
              </div>
            </div>
          )}

          {/* FORECAST */}
          {forecast && (
            <div className="animate-fadeUp rounded-lg border border-teal-200 bg-teal-50/60 px-3 py-2">
              <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-teal-700"><StageIcon stage="forecast" /> Forecast / Scenario</div>
              <div className="mt-0.5 text-[12px] text-teal-800">{forecast.note}</div>
            </div>
          )}

          {/* SYNTHESIZE */}
          {synth && (
            <div className="animate-fadeUp">
              <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-ramsay-500"><StageIcon stage="synthesize" /> Synthesize</div>
              <div className="text-[12px] text-ramsay-600">
                Fused results from{' '}
                {(synth.sources || []).map((s: string, i: number) => (
                  <span key={i} className="font-semibold text-ramsay-800">{s}{i < synth.sources.length - 1 ? ', ' : ''}</span>
                ))}
                {synth.chart && <span className="ml-1 rounded bg-ramsay-100 px-1.5 py-0.5 text-[10px] font-semibold text-ramsay-600">+ chart</span>}
              </div>
            </div>
          )}

          {errEvt && (
            <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-[12px] text-rose-700">
              <span className="font-semibold">Error: </span>{errEvt.message}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
