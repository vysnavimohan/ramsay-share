// Token acquisition: works in Databricks Apps (SP OAuth via client credentials)
// and locally (Azure AD CLI token). Cached in memory ~40 min.
import { execFile } from 'node:child_process';

const AAD_RESOURCE = '2ff814a6-3304-4ab8-85cb-cd0e6f879c1d'; // AzureDatabricks
let cache = { tok: null, at: 0 };

function azToken() {
  return new Promise((resolve, reject) => {
    execFile(
      'az',
      ['account', 'get-access-token', '--resource', AAD_RESOURCE, '--query', 'accessToken', '-o', 'tsv'],
      (err, stdout) => (err ? reject(err) : resolve(stdout.trim())),
    );
  });
}

async function spOAuthToken(host) {
  const clientId = process.env.DATABRICKS_CLIENT_ID;
  const clientSecret = process.env.DATABRICKS_CLIENT_SECRET;
  if (!clientId || !clientSecret) throw new Error('No SP credentials');
  const body = new URLSearchParams({
    grant_type: 'client_credentials',
    client_id: clientId,
    client_secret: clientSecret,
    scope: 'all-apis',
  });
  const r = await fetch(`${host}/oidc/v1/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  if (!r.ok) throw new Error(`OAuth token failed: ${r.status} ${await r.text()}`);
  const j = await r.json();
  return j.access_token;
}

export async function getToken(host) {
  if (cache.tok && Date.now() - cache.at < 40 * 60 * 1000) return cache.tok;
  let tok;
  if (process.env.DATABRICKS_CLIENT_ID && process.env.DATABRICKS_CLIENT_SECRET) {
    tok = await spOAuthToken(host);
  } else {
    tok = await azToken();
  }
  cache = { tok, at: Date.now() };
  return tok;
}
